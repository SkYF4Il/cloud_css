/*
 * Chapitre 6: Modularité du Code
 * Ecriture de Fonctions -- Exercice 3 (opération arithmétique)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <assert.h>

/*
 * Définition du Problème:
 *  - Input: deux valeurs flottantes et un caractère représentant une opération
 *           arithmétique
 *  - Output: on affiche à l'écran le résultat de x op y
 *  - Objets Utilisés:
 *    x, y des nombres réels
 *      float x, y;
 *    op, un caractère représentant l'opération à effectuer
 *      char op;
 *
 * Analyse du Problème:
 *  - SP1: lecture de x, y, op au clavier
 *  - SP2: l'évaluation de x op y
 *  - SP3: affichage du résultat
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3
 *
 * Le SP2 peut être "sorti" du programme principal pour en faire une fonction.
 */



/*
 * SP2
 * Définition du Problème:
 *  - Input: deux nombres réels (x, y) et une opération (op)
 *  - Output: x op y
 *  - Objets Utilisés:
 *    x, y des nombres réels
 *    op représentant l'opération arithmétique
 *      paramètres formels de la fonction
 *
 * @pre: x!=0, y!=0
 * @post: x op y, où op appartient à {+, -, *, /}
 */
float operation(float x, float y, char op){
  assert(x!=0.0 && y!=0.0);
  float resultat;

  switch(op){
    case '-':
      resultat = x - y;
      break;
    case '*':
      resultat = x * y;
      break;
    case '/':
      resultat = x / y;
      break;
    default:
      resultat = x + y;
  }//fin switch()

  return resultat;
}//fin operation()

int main(){
  float x, y;
  char op;

  //SP1
  printf("Introduisez les valeurs de x, y, et op: ");
  scanf("%f %f %c", &x, &y, &op);

  //SP2 + SP3
  printf("%f\n", operation(x, y, op));

  return 0;
}//fin programme
