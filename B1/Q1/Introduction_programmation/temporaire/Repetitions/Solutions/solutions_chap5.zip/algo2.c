/*
 * Chapitre 5: Structures de Données
 * Algo. tableaux -- Exercice 2 (Renversement de tableau)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

/*
 * Défintion du Problème:
 *  - Input: un tableau à N valeurs entières
 *  - Output: affichage à l'écran du tableau renversé
 *            les éléments du tableau sont affichés entre crochets.
 *  - Objets Utilisés:
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsgined short N = 20;
 *      tab est un tableau d'entiers
 *        int tab[N];
 *
 * Analyse du Problème:
 *  - SP 1: remplissage du tableau {tab}
 *  - SP 2: renversement de {tab} dans un tableau intermédiaire {renverse}
 *  - SP 3: affichage de {renverse}
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3
 */

int main(){
  const unsigned short N = 20;
  int tab[N];
  int renverse[N];

  unsigned short i;

  /*
   * SP 1: remplir le tableau {tab} avec {N} valeurs entières lues au
   * clavier.
   *
   * Invariant:
	 *
	 *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          rempli       encore
	 *        au clavier    à remplir
	 *
	 * Fonction de terminaison: N-i
   */
  i = 0;
  while(i<N){
    printf("Entez la %deme valeur du tableau: ", i+1);
    scanf("%d", &tab[i]);
    i++;
  }//fin while - i

  /*
   * SP 2: renversement du tableau tab dans renverse
   *
   * Inv:
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          déjà       encore
	 *        renversé    à renverser
   *
   *
   *            |0        i|         N-1|N
	 *            +----------+-------------+
	 * renverse:  |          |             |
	 *            +----------+-------------+
	 *             <--------> <----------->
   *                à            rempli par renversement de tab
   *              renverser
   * tels que renverse[N-1-i-1 ... N-1] = tab[0 ... i-1]
   *
   * Fonction de terminaison: N-i
   */
  i = 0;
  while(i<N){
    renverse[N-1-i] = tab[i];
    i++;
  }//fin while

  /*
   * SP 3: affichage de renverse
   *
   * Inv:
   *            |0         |i         N-1|N
	 *            +----------+-------------+
	 * renverse:  |          |             |
	 *            +----------+-------------+
	 *             <--------> <----------->
   *              affiché        encore à afficher
   *              à l'écran
   *
   * Fonction de terminaison: N-i
   */
  printf("[ ");
  i = 0;
  while(i<N){
    printf("%d ", renverse[i]);
    i++;
  }//fin while - i

  printf("]\n");
}//fin programme
