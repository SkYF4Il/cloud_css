/*
 * Chapitre 5: Structures de Données
 * Tableaux Multi. -- Exercice 4 (Transposée d'une matrice)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

/*
 * Définition du Problème
 *  - Input: une matricesd'entier de dimension N*M
 *  - Output: affichage de la transposée de A
 *  - Objets Utilisés:
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code.
 *        const unsigned short N = 2;
 *      M est un entier Naturel.  Il ne doit pas être modifié dans le code.
 *        const unsigned short M = 3;
 *      A est une matrice de valeurs entières.
 *        int A[N][M];
 *
 * Analyse du Problème:
 *  - SP 1: remplissage de la matrice {A} (possibilité de raffiner en 2 SPs)
 *  - SP 2: affichage de la matrice {A} (possibilité de raffiner en 2 SPs)
 *  - SP 3: transposition de la matrice {A} dans {B} (possibilité de raffiner en 2 SPs)
 *  - SP 4: affichage de la matrice {B} (possibilité de raffiner en 2 SPs)
 *
 * Enchaînements des SPs:
 *  SP1 -> SP2 -> SP3 -> SP4
 */

 int main(){
   //dimensions des matrics
   const unsigned short N = 2;
   const unsigned short M = 3;

   //les matrices
   int A[N][M];
   int B[M][N];

   unsigned short i, j;

   /*
   * SP 1: remplissage de la matrice A.
   * Invariant:
   *   0<=i<=N, j'ai déjà lu clavier les (i) première lignes de la matrice A.
   *
   * Fonction de Terminaison: N-i
   */
   for(i=0; i<N; i++){
     /*
     * Invariant:
     * 0<=j<=M, 0<=i<N, j'ai déjà lu au clavier les (j) première colonne de la
     *        ligne d'indice i de la matrice A.
     *
     * Fonction de Terminaison: M-j
     */
     for(j=0; j<M; j++){
       printf("Elément[%hu][%hu] : ", i, j);
       scanf("%d", &A[i][j]);
     }//fin for - j
   }//fin for - i

   /*
   * SP 2: affichage de la matrice A
   */
   printf("Matrice donnée :\n");
   for(i=0; i<N; i++){
     for(j=0; j<M; j++)
      printf("%3d", A[i][j]);
     printf("\n");
   }//fin for - i

   /*
   * SP 3: transposition de la matrice A dans B
   *
   * Invariants: à faire par les étudiants
   */
   for(i=0; i<N; i++){
     for(j=0; j<M; j++)
      B[j][i]=A[i][j];
   }//fin for - i

   /*
   * SP 4: affichage du résulat
   * Attention: maintenant le rôle de N et M est inversé.
   *
   * Invariant(s) & Fonction(s) de Terminaison:
   *    cfr. Exercice 1 sur les tableaux multidimensionnels  (à adapter)
   */
   printf("Matrice résultat :\n");
   for(i=0; i<M; i++){
     for(j=0; j<N; j++)
      printf("%7d", B[i][j]);
     printf("\n");
   }//fin for - i
 }//fin programme
