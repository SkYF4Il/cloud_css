/*
 * Chapitre 2: Structures de Contrôle
 * Manipulation Itération -- Exercice 4 (do ... while)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  int i = 1;

  do{
    printf("It's a long way to the top if you wanna Rock 'n' Roll!\n");
    i++;
  }while(i<=5);
}//fin programme
