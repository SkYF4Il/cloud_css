/*
 * Chapitre 3: Méthodologie
 * Construction par Invariants -- Exercice 8
 * (approximation d'une dichotomie par racine carrée)
 *
 * @author: Benoit Donnet, Simon Lienardy (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <math.h>

/*
 * Définition du Problème:
 *  - Input: n, la valeur pour laquelle on cherche la racine carrée
 *  - Output: l'approximation de la racine carrée est affichée à l'écran
 *  - Objets Utilisés:
 *    PRECISION, la précision attendue de l'approximation (non modifié par le code)
 *      const float PRECISION = 0.0005;
 *    n, une valeur entière positive
 *      unsigned int n;
 *
 * Analyse du Problème:
 *  SP1: lecture de n au clavier
 *  SP2: approximation de la racine carrée
 *  SP3: affichage de l'approximation
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3
 */

int main(){
  float debut, fin, milieu;
  const float PRECISION = 0.005;
  unsigned int n;

  /*
   * SP1: lecture au clavier
   */
  printf("Entrez une valeur: ");
  scanf("%u", &n);



  /*
   * SP2: approximation de la racine carrée
   *
   * Invariant Graphique:
   * 
   *  0     debut      sqrt(n)     fin        n
   *  |-------|----------|----------|---------|-----------> N
   *   <----->                       <------->
   *   . < sqrt(n)                      .> sqrt(n)
   * à une PRECISION près
   * milieu = (debut + fin) / 2
   *
   * Fonction de terminaison: fin - debut - PRECISION
   */
  debut = 0;
  fin = n;
  milieu = (debut + fin) / 2;
  while(debut + PRECISION < fin){
    if((milieu * milieu) <= n)
      debut = milieu;
    else
      fin = milieu;

    milieu = (debut+fin)/2;
  }//fin while

  //SP3
  printf("racine carrée: %f\n", sqrt(n));
  printf("approximation par défaut: %f\n", debut);
  printf("approximation par excès: %f\n", fin);
}//fin programme
