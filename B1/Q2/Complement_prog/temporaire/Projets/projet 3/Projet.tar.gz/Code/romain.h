/**
 * \file romain.h
 * \brief Header pour le calcul récursif d'un nombre romain
 * \author Benoit Donnet, Simon Liénardy -- Université de Liège (ULiège)
 * \version 0.1
 * \date 03/04/2020
 *
 * Convertis un nombre romain en nombre décimal
 */

#ifndef __ROMAIN__
#define __ROMAIN__

/**
 * \fn unsigned int romain_rec(char *chiffres, unsigned int n)
 * \brief Convertir un nombre romain en nombre arabe
 *
 * \param chiffres, le nombre romain
 * \param n, le nombre de chiffres dans le nombre romain.
 *
 * \return la représentation décimale du nombre romain.
 */
unsigned int romain_rec(char *chiffres, unsigned int n);

#endif
