/*
 * Chapitre 5: Structures de Données
 * Tableaux Multi. -- Exercice 3 (matrice carrée unitaire)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

/*
 * Définition du Problème
 *  - Input: /
 *  - Output: affichage de la matrice identité
 *  - Objets Utilisés:
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code.
 *        const unsigned short N = 3;
 *      matUnitaire est une matrice (carrée) de valeurs entières.
 *        int matUnitaire[N][N];
 *
 * Analyse du Problème:
 *  - SP 1: construction de la matrice carrée unitaire (peut être raffiné en 2 SPs)
 *  - SP 2: affichage du résultat (peut être raffiné en 2 SPs)
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2
 */

int main(){
  //dimension de la matrice
  const unsigned short N = 10;

  //la matrice unitaire
  int matUnitaire[N][N];

  unsigned short i, j;

  /*
   * SP 1: construction de la matrice carrée unitaire
   *
   * Invariant:
   *                   |0                    N-1|N
   *                  -+------------------------+ ––
   *                  0|                        |   |
   *                   |                        |   | matrice unité créée
   *                   ...        ...         ...   |
   *  matUnitaire:  i-1|                        | __|
   *                 --------------------------------
   *                  i|                        | --
   *                   ...        ...         ...   |
   *                N-1|                        |   |  encore à remplir
   *                  -+------------------------+ ––
   *                  N
   *
   * Fonction de terminaison: N-i
   */
  for(i=0; i<N; i++){
    /*
     * Remplissage de la ligne courante
     *
     * Invariant:
     *                  |0         |i         N-1|N
  	 *                  +----------+-------------+
  	 * matUnitaire[i]:  |. = (i==j)|             |
  	 *                  +----------+-------------+
  	 *
     * Fonction de terminaison: N-j
     */
    for(j=0; j<N; j++)
      matUnitaire[i][j] = (i==j);

    /*
     * Note: l'instruction unique du corps de la boucle di-dessus:
     *  matUnitaire[i][j] = (i==j);
     * n'est pas forcément "jolie" mais assez pratique à écrire.
     * Elle est équivalent à ceci:
     * if (i == j)
     *      matUnitaire[i][j] = 1;
     * else
     *      matUnitaire[i][j] = 0;
     */
  }//fin for - i

  /*
   * SP 2: affichage du résultat
   *
   * Invariant(s) & Fonction(s) de Terminaison:
   *    cfr. Exercice 1 sur les tableaux multidimensionnels
   */
  printf("Matrice unitaire de dimension %d :\n", N);
  for(i=0; i<N; i++){
    for(j=0; j<N; j++)
      printf("%3d", matUnitaire[i][j]);
    printf("\n");
  }//fin for - i
}//fin programme
