/*
 * Chapitre 3: Méthodologie
 * Construction par Invariant -- Exercice 6
 * (représentation d'un nombre naturel sous la forme d'une somme de puissance de 2)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2020
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  - Input: n, un nombre entier positif
 *  - Output: la somme des puissances de 2 composant n est affichée
 *  - Objets Utilisés:
 *    n, un entier positif
 *      unsigned int n;
 *
 * Analyse du Problème:
 *  SP1: lecture au clavier de n
 *  SP2: Décomposition en puisance de 2 de n
 *  SP3: affichage des termes de la somme
 *
 * Enchaînement des SPs:
 *  SP1 -> (SP3 \inclus SP2)
 *
 * Idée pour une solution
 * 0. Pour décomposer un nombre en puissance de 2, on initialise la puissance
 *    de 2 courante à 1 (i.e., 2^0).
 * 1. Si le nombre est impair, alors la puissance courante apparaît dans
 *    la décomposition. Sinon, elle n'apparaît pas.
 * 2. On divise ensuite le nombre par 2 (division entière) et on multiplie par
 *    2 la puissance courante.
 * 3. On recommence à l'étape 1.
 */

int main(){
  unsigned int n, puissance;

  /*
  * SP1: lecture au clavier
  */
  printf("Entrez la valeur de n: ");
  scanf("%u", &n);

  //puissance est initialisé à 2^0 (i.e., 1)
  printf("%u = ", n);
  puissance = 1;

  /*
   * SP2: décomposition en puissance
   *
   * Invariant (formel):
   *  puissance = 2^i  (i indique le nombre de tours...)
   *  n = n0/2^i (où n0 est la valeur initiale de n)
   *  i >= 0
   *
   * Fonction de terminaison: n > 0
   */
  while(n>0){
    if(n%2){
      /*
      * n impair => la puissance de 2 courante apparaît dans la somme
      * SP3
      */
      printf("%u + ", puissance);
    }

    //je passe à la puissance suivante
    puissance *= 2;
    n /= 2;
  }//fin while
  printf("\n");
}//fin programme
