/*
 * Chapitre 8: Allocation Dynamique
 * Ecriture de Code -- Exercice 8 (Matrice dans un fichier)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

/*
 * Alloue dynamiquement une matrice de dimension n*m.
 * @pre: n>0, m>0
 * @post: retourne un pointeur sur une matrice allouée, chaque élément étant mis à 0.
 *        NULL en cas d'erreur
 */
int **alloue_matrice(unsigned int n, unsigned int m){
  assert(n>0 && m>0);

  int i, j;

  //création des lignes de la matrice
  int **matrice = malloc(n * sizeof(int *));
  if(matrice == NULL)
  return NULL;

  /*
   * Invariant:
   * les colonnes dans la sous-matrice matrice[0 ... i-1] ont été allouées
   * 0 <= i <= n
   *
   * Fonction de terminaison: n-i
   */
  for(i=0; i<n; i++){
    matrice[i] = malloc(m*sizeof(int));

    if(matrice[i]==NULL){
      //libération de la mémoire déjà allouée
      for(j=0; j<i; j++)
        free(matrice[j]);

      free(matrice);

      return NULL;
    }

    for(j=0; j<m; j++)
      matrice[i][j] = 0;
  }//fin for - i

  return matrice;
}//fin alloue_matrice()

/*
 * Libère la mémoire allouée à une matrice (n est la dimension des lignes de la matrice)
 * @pre: matrice!=NULL, n>0.
 * @post: la mémoire occupée par matrice est libérée.
 */
void libere_matrice(int **matrice, unsigned int n){
  assert(matrice!=NULL && n>0);

  int i;

  /*
   * Invariant:
   * matrice[0...i-1] a été libéré, avec 0 <= i <= n
   *
   * Fonction de terminaison: n-i
   */
  for(i=0; i<n; i++)
    free(matrice[i]);

  free(matrice);
}//fin libere_matrice()

/*
 * Charge le contenu d'un fichier dans une matrice.
 * @pre: matrice!=NULL, fichier!=NULL, n>0, m>0
 * @post: 1 si le fichier a bien été chargé dans la matrice.
 *        -1 en cas d'erreur
 */
int charge_matrice(int **matrice, unsigned int n, unsigned int m, char *fichier){
  assert(matrice!=NULL && n>0 && m>0 && fichier!=NULL);

  int i, j;

  //ouverture fichier
  FILE *fp = fopen(fichier, "r");
  if(fp==NULL)
  return -1;

  //lecture fichier (pour chaque ligne, on lit les colonnes)
  for(i=0; i<n; i++)
    for(j=0; j<m; j++)
      fscanf(fp, "%d", &matrice[i][j]);

  //fermeture fichier
  fclose(fp);

  return 1;
}//fin charge_matrice()

/*
 * Calcule la somme des éléments d'un tableau.
 * @pre: tab!=NULL, n>0
 * @post: la somme des éléments du tableau
 */
int somme_tableau(int *tab, unsigned int n){
  assert(tab!=NULL && n>0);
  int somme = 0, i;

  /*
   * Invariant:
   *       |0         |i         n-1|n
   *       +----------+-------------+
   * tab:  |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *        somme calculée  encore à sommer
   *        dans somme
   *
   * Fonction de terminaison: n-i
   */
  for(i=0; i<n; i++)
    somme += tab[i];

  return somme;
}//fin somme_tableau()

/*
 * Calcule la somme des lignes de la matrice.
 * @pre: matrice!=NULL, n>0, m>0
 * @post: un tableau contenant la somme de chaque ligne de la matrice.
 *        NULL en cas d'erreur
 */
int *somme_ligne(int **matrice, unsigned int n, unsigned int m){
  assert(matrice!=NULL && n>0 && m>0);
  int i;

  //création du tableau résultat
  int *tab = malloc(n*sizeof(int));
  if(tab==NULL)
    return NULL;

  /*
  * Invariant:
  * tab[0...i-1] contient la somme des i premières lignes de matrice
  * 0 <= i <= n
  *
  * Fonction de terminaison: n-i
  */
  for(i=0; i<n; i++)
    tab[i] = somme_tableau(matrice[i], m);

  return tab;
}//fin somme_ligne()

int main(int argc, char **argv){
  int n, m, i, res;
  int **matrice;

  if(argc!=3){
    printf("Usage: ./main n m");
    return -1;
  }

  //récupérer les arguments et les tranformer de char* vers unsigned int
  n = atoi(argv[1]);
  m = atoi(argv[2]);
  matrice = alloue_matrice(n, m);
  if(matrice==NULL)
    return -1;

  res = charge_matrice(matrice, n, m, "fichier.txt");
  if(res==-1)
    return -1;

  int *tab = somme_ligne(matrice, n, m);

  printf("[ ");
  for(i=0; i<n; i++)
    printf("%d ", tab[i]);
  printf("]\n");

  libere_matrice(matrice, n);
  free(tab);

  return 0;
}//fin programme
