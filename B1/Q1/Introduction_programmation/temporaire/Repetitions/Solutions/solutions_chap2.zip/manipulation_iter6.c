/*
 * Chapitre 2: Structures de Contrôle
 * Manipulation Itération -- Exercice 6 (do ... while)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  int n=5;
  int f=1;
  int c=n;

  do{
    f = f*c;
    c--;
  }while(c>1);

  printf("%d\n", f);
}//fin programme
