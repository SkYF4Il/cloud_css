/*
 * Chapitre 2: Structures de Contrôle
 * Manipulation Itération -- Exercice 3 (while)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  int i = 0;

  while(i<5){
    printf("It's a long way to the top if you wanna Rock 'n' Roll!\n");
    i++;
  }//fin while - i
}//fin programme
