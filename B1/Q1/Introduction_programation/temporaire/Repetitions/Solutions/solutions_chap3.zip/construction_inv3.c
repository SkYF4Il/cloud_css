/*
 * Chapitre 3: Méthodologie
 * Construction par Invariants -- Exercice 3 (suite de Fibonacci)
 *
 * @author: Benoit Donnet (ULiege)
 * Mise à Jour: Novembre 2018
 */

#include<stdio.h>

/*
 * Définition du Problème:
 *  - Input: n, le terme de la suite de fibonacci
 *  - Output: f(n) est affiché à l'écran
 *  - Objets Utilisés:
 *    n, un nombre naturel
 *    unsigned int n;
 *
 * Analyse du Problème:
 *  SP1: lecture au clavier
 *  SP2: calcul des termes de la suite de Fibonacci
 *  SP3: affichage du nème terme de la suite
 *
 * Enchaînement des Sous-Problèmes:
 *  SP1 -> (SP3 \inclus SP2)
 */

int main(){
  /*
  * n est le nombre de termes dans la série de Fibonacci
  * premier est le premier terme de fibonacci dans la formule récursive: f(n-1)
  * deux est le deuxième terme de fibonacci dans la formule récursive: f(n-2)
  * fibo est le résultat de la suite de fibonacci
  */
  unsigned int n, premier = 0, deux = 1, fibo, c;

  /*
   * SP1: lecture au clavier
   */
  printf("Entrez le nombre de termes: ");
  scanf("%u",&n);

  printf("Les %u premiers termes de Fibonacci sont:-\n",n);

  /*
   * SP2: calcul des n termes
   *
   * Invariant Graphique:
   *
   *  0  1  2  3              c-1 c               n  n+1
   *  |--|--|--|     ....    --|--|     ....    --|--|--------------> N
   *  <------------------------>
   *      fibo = f(c-1)
   */
  c = 0;
  while(c <= n){
    if(c<=1)
      fibo = c;
    else{
      fibo = premier + deux;
      premier = deux;
      deux = fibo;
    }
    //SP3
    printf("%u\n",fibo);

    c++;
  }//fin while - c
}//fin programme
