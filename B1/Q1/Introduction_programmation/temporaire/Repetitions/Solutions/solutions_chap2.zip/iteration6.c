/*
 * Chapitre 2: Structures de Contrôle
 * Itérations -- Exercice 7 (+ grande puissance de 2 inférieure à N)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  const unsigned int N = 2426555645;
  unsigned int n;
  unsigned int i=1; //unsigned int car sinon, overflow

  /*
  * 4 questions:
  *  1. compteur et initialisation?
  *     n = N (où N est le plus grand naturel possible)
  *  2. nombre de tours de boucle?
  *     log_2(n) puisqu'on essaie de décomposer n en puissance de 2 (on le
  *     division donc par 2 à chaque étape)
  *  3. gardien de boucle?
  *     n/2>0 (on s'arrête un tour plus tôt car on veut la + grande puissance de 2
  *     inférieure à N)
  *  4. corps de boucle?
  *     multiplier i par 2 (afin d'obtenir des puissances de 2)
  *     division n par 2
  */
  for(n=N; n/2>0; n = n/2)
    i*=2;

  printf("%u\n", i);
}//fin programme
