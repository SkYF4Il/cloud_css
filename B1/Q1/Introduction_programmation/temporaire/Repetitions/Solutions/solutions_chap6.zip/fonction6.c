/*
 * Chapitre 5: Modularité du Code
 * Ecriture de Fonctions -- Exercice 6 (analyse de fonction)
 *
 * La découpe en sous-problèmes est donnée directement par l'énoncé.
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <math.h>

/*
 * @pre: /
 * @post: f(x), avec f définit comme ((2*x^2+3)(x^2-1))/sqrt(3*x^2+1)
 */
double image_f(double x){
  double numerateur;
  double denominateur;

  numerateur = (2*(x*x)+3)*((x*x)-1);
  denominateur = sqrt(3*(x*x)+1);

  return numerateur/denominateur;
}//fin image_f()

/*
 * @pre: /
 * @post: f'(x)
 */
double approx_derivee(double x, double h){
  double tmp1, tmp2;

  tmp1 = image_f(x+h);
  tmp2 = image_f(x);

  return (tmp1 - tmp2)/h;
}//fin approx_derivee()

/*
 * @pre: /
 * @post: f''(x)
 */
double approx_derivee_seconde(double x, double h){
  double tmp1, tmp2, image;

  tmp1 = image_f(x+h);
  tmp2 = image_f(x-h);
  image = image_f(x);

  return (tmp1+tmp2-2*image)/h*h;
}//fin approx_derivee_second()

/*
 * @pre: /
 * @post: -1 si f''(x) < 0, 1 sinon.
 */
short signe_derivee_seconde(double x, double h){
  double derivee_seconde;

  derivee_seconde = approx_derivee_seconde(x, h);

  if(derivee_seconde < 0)
    return -1;
  else
    return 1;
}//fin signe_derivee_seconde()

/*
 * @pre: /
 * @post: le menu est affiché sur la sortie standard
 */
void menu(){
  printf("Faites votre choix: \n");
  printf("\t1. Calcul de l'image de f\n");
  printf("\t2. Calcul de la dérivée première de f\n");
  printf("\t3. Calcul de la dérivée seconde de f\n");
  printf("\t4. Signe de la dérivée seconde de f\n");
  printf("\t5. Quitter\n");
}//fin menu()

int main(){
  unsigned short fin = 0;
  unsigned short choix;
  double x, h;

  while(!fin){
    menu();
    scanf("%hu", &choix);

    switch(choix){
      case 1:
        printf("Entrez une valeur pour x: ");
        scanf("%lf", &x);
        printf("La valeur de f(x) est: %lf\n", image_f(x));

        break;
      case 2:
        printf("Entrez une valeur pour x et h: ");
        scanf("%lf %lf", &x, &h);
        printf("La valeur de f'(x) est: %lf\n", approx_derivee(x, h));

        break;
      case 3:
        printf("Entrez une valeur pour x et h: ");
        scanf("%lf %lf", &x, &h);
        printf("La valeur de f''(x) est: %lf\n", approx_derivee_seconde(x, h));

        break;
      case 4:
        printf("Entrez une valeur pour x et h: ");
        scanf("%lf %lf", &x, &h);
        if(signe_derivee_seconde(x, h)==1)
          printf("La dérivée seconde est positive\n");
        else
          printf("La dérivée seconde est négative\n");

        break;
      case 5:
        fin = 1;

        break;
      default:
        printf("Mauvaise valeur entrée!!\n");
    }//fin switch
  }//fin while

  return 0;
}//fin programme
