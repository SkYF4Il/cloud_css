/*
 * Chapitre 5: Structures de Données
 * Fichiers -- Exercice 2 (Répertoire)
 *
 * @author: Benoit Donnet (ULièg)
 * Mise à Jour: Novembre 2018
 *
 * Nous verrons lors du cours "Compléments de Programmation" (INFO0947) comment
 * écrire proprement des invariants pour des fichiers séquentiels.
 */

/*
 * Etape 1 de la manipulation des fichiers: include la librairie d'E/S
 */
#include <stdio.h>
#include <stdlib.h>

/*
 * Structure permettant de manipuler une personne.
 * Ce n'est pas nécessaire dans le programme/l'exercice mais
 * c'est plus élégant.
 */
typedef struct{
  char nom[21];
  char prenom[16];
  unsigned short age;
  char telephone[12];
}Personne;

int main(){
  Personne p;
  unsigned short fin = 0;

  /*
  * Etape 2 de la manipulation des fichiers: déclarer une variable de
  * type "pointeur sur file".
  */
  FILE *fp;

  /*
  * Etape 3 de la manipulation des fichiers: ouvrir le fichier avec le
  * bon mode de manipulation (ici, écriture).
  */
  fp = fopen("repertoire.txt", "w");

  /*
  * Etape 4 de la manipulation des fichiers: vérifier si l'ouverture
  * du fichier s'est bien passée ou non.
  */
  if(fp==NULL){
    //échec de l'ouverture
    printf("Impossible d'ouvrir le fichier en écriture\n");
    exit(-2);
  }

  /*
  * Etape 5 de la manipulation des fichiers: écriture des informations
  */
  while(!fin){
    printf("Entrez une nouvelle personne:\n");
    printf("\t nom (max 20 caractères): ");
    scanf("%20s", p.nom);
    printf("\t prénom (max 15 caractères): ");
    scanf("%15s", p.prenom);
    printf("\t age: ");
    scanf("%hu", &p.age);
    printf("\t téléphone (max 11 caractères): ");
    scanf("%11s", p.telephone);

    fprintf(fp, "%s\n%s\n", p.nom, p.prenom);
    fprintf(fp, "%hu\n%s\n", p.age, p.telephone);

    printf("Désirez-vous encoder une nouvelle personne (0 pour oui, 1 pour non): ");
    scanf("%hu", &fin);
  }//fin while()

  /*
  * Etape 6 de la manipulation des fichiers: fermeture du fichier
  */
  fclose(fp);
}//fin programme
