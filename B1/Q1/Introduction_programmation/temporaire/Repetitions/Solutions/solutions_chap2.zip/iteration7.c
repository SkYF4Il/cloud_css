/*
 * Chapitre 2: Structures de Contrôle
 * Itérations -- Exercice 2 (dessin d'un rectangle)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  int longueur, largeur;
  int i,j;

  printf("Entrez la longueur et la largeur: ");
  scanf("%d %d", &longueur, &largeur);

  //écriture de la longueur
  printf("+");
  /*
  * 4 questions:
  *  1. compteur et initialisation?
  *     i = 1
  *  2. nombre de tours de boulce?
  *     longeur-2 (longeur donne le nombre de tirets)
  *  3. gardien de boucle?
  *     i < longueur - 1
  *  4. corps de boucle?
  *     afficher un tiret
  *     incrémenter le compteur de boucle i
  */
  for(i=1; i<longueur-1; i++)
    printf("-");
  printf("+\n");

  //écriture des largeurs
  /*
  * 4 questions:
  *  1. compteur et initialisation?
  *     i = 1
  *  2. nombre de tours de boulce?
  *     largeur-1
  *  3. gardien de boucle?
  *     i < largeur
  *  4. corps de boucle?
  *     afficher le côté gauche du rectangle ('|’))
  *     afficher les espaces à l'intérieur (boucle!!)
  *     afficher le côté droit du rectangle ('|’))
  *     passer à la ligne
  *     incrémenter le compteur de boucle i
  */
  for(i=1; i<largeur; i++){
    printf("|");
    /*
    * 4 questions:
    *  1. compteur et initialisation?
    *     j = 1
    *  2. nombre de tours de boulce?
    *     longueur-2
    *  3. gardien de boucle?
    *     i < longueur-1
    *  4. corps de boucle?
    *     afficher un espace
    *     incrémenter le compteur de boucle j
    */
    for(j=1; j<longueur-1; j++)
      printf(" ");
    printf("|\n");
  }//fin for - i

  //écriture de la longueur
  printf("+");

  /*
  * 4 questions:
  *  1. compteur et initialisation?
  *     i = 1
  *  2. nombre de tours de boulce?
  *     longeur-2 (longeur donne le nombre de tirets)
  *  3. gardien de boucle?
  *     i < longueur - 1
  *  4. corps de boucle?
  *     afficher un tiret
  *     incrémenter le compteur de boucle i
  */
  for(i=1; i<longueur-1; i++)
    printf("-");
  printf("+\n");
}//fin programme
