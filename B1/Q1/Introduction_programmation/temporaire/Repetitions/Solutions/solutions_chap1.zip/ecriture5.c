/*
 * Chapitre 1: Blocs, Variables, Instructions Simples
 * Ecriture de Code -- Exercice 5 (périmètre/aire d'un disque)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  float rayon, perimetre, aire;

  printf("Entrez le rayon : ");
  scanf("%f", &rayon);

  perimetre = 2.0 * M_PI * rayon;
  aire = M_PI * rayon * rayon;

  printf("Périmètre = %f\nAire = %f\n", perimetre, aire);
}//fin programme
