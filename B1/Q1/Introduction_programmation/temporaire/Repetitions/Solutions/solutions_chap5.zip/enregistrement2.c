/*
 * Chapitre 5: Structures de Données
 * Enregistrement -- Exercice 2 (structure de données pour une personne)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

typedef struct{
  char[31] nom;
  char[31] prenom;
  unsigned short age;
  char sexe; //'M' pour garçon, 'F' pour fille
}Personne;

int main(){
    Personne p;
}//fin programme
