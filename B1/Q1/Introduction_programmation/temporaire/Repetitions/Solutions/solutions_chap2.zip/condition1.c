/*
 * Chapitre 2: Structures de Contrôle
 * Conditions -- Exercice 1 (TVA)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  float prix, tva, ttc;
  char type;

  printf("Entrez un prix : ");
  scanf("%f", &prix);

  printf("Produit de type A ou B ? ");
  scanf("%s", &type);

  if(type == 'A')
    tva = 5.5;
  else
    tva = 19.6;

  ttc = prix * (1.0 + tva / 100.0);

  printf("Prix TTC : %f (TVA à %.1f %%)\n", ttc, tva);
}//fin programme
