/*
 * Chapitre 6: Modularité du Code
 * Ecriture de Fonctions -- Exercice 9 (compter les positifs dans une matrice carrée)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <assert.h>

/*
 * sous-problème: compter la quantité de nombres >=0 dans un tableau (uni-dimensionnel)
 * @pre: tab est un tableau valide, n>0
 * @post: la quantité de nombres >=0 dans tab
 */
unsigned int positif_tableau(int tab[], unsigned int n){
  assert(n > 0 && tab!=NULL);
  unsigned int i;
  unsigned int positif = 0;

  /*
  * Invariant:
  *       |0         |i         n-1|n
  *       +----------+-------------+
  * tab:  |          |             |
  *       +----------+-------------+
  *        <--------> <----------->
  *          positif       encore à vérifier
  *        contient la
  *       quantité de nombre positifs
  *       dans tab[0...i-1]
  *
  * Fonction de terminaison:  n-i
  */

  for(i=0; i<n; i++)
  positif += (tab[i]>=0);

  return positif;
}//fin positif_tableau()

/*
 * Note: pour que cela compile, traitement particulier de la signature de la fonction.
 *
 * @pre: matrice est valide et de dimension n*n, n>0
 * @post: retourne le nombre d'éléments de la matrice qui sont >=0
 */
unsigned int nPositifs(int matrice[][2], unsigned int n){
  assert(matrice!=NULL && n > 0);
  unsigned int positif = 0;
  unsigned int i;

  /*
  * Invariant:
  *               |0                    n-1|n
  *              -+------------------------+ ––
  *              0|                        |   |
  *               |                        |   | positif contient la quantité de nombre>=0
  *               ...        ...         ...   | dans matrice[0 ... i-1]
  *  matrice:  i-1|                        | __|
  *            --------------------------------
  *              i|                        | --
  *               ...        ...         ...   |
  *            n-1|                        |   |  encore à vérifier
  *              -+------------------------+ ––
  *              n
  *
  * Fonction de terminaison: n-i
  */
  for(i=0; i<n; i++)
    /*
     * Sous-problème: je traite la ligne courante avec un fonction particulière chargée,
     * pour cette ligne, de déterminer la quantité de nombres >=0.
     */
    positif += positif_tableau(matrice[i], n);

  return positif;
}//fin nPositifs()

int main(){
  int matrice[2][2] = {{1, 2}, {-1, 3}};

  printf("%u\n", nPositifs(matrice, 2));

  return 0;
}//fin programme
