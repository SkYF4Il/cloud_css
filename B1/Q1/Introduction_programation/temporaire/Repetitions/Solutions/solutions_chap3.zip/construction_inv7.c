/*
 * Chapitre 3: Méthodologie
 * Construction par Invariant -- Exercice 7
 * (Représentation binaire d'un nombre entier signé)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2020
 */

#include <stdio.h>
#include <math.h>

/*
 * Définition du problème.
 *  - Input: n, la valeur pour laquelle il faut trouver la représentation binaire
 *  - Output: la représentation binaire de n est affichée à l'écran
 *  - Objets Utilisés:
 *      n, un entier positif
 *        unsigned int n
 *      TAILLE, la quantité de bits sur laquelle on travaille (non modifié par le code)
 *        const unsigned short TAILLE = 32;
 *
 * Analyse du Problème:
 * Note: le cas n=0 est trivial.  Il ne sera pas traité ici (on se place donc
 * dans une situation ou n > 0)
 *  SP1: lecture de n au clavier
 *  SP2: décomposition binaire de n avec affichage des bits.
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2
 *
 * Idée de solution:
 * la transformation du décimal vers le binaire se fait de la manière la plus
 * classique. (i.e., comme les entiers non signés - cfr. Introduction du cours)
 *
 * L'idée est de parcourir les différentes puissances de 2 (à partir de TAILLE)
 * et de les diminuer de 1 à chaque tour de boucle.
 * A chaque tour de la boucle, on vérifie si la puissance de 2 courante est
 * incluse (ou non) dans n.
 *
 * Note sur l'opérateur "<<": il permet de faire un décalage de bits vers la
 * gauche.  x << y décale les bits de x de y positions vers la gauche.
 * exemple: si x correspond à la suite de bits "0010" et y correspond à 2,
 * alors l'opération "x << y" donne comme résulat: "1000".  Si maintenant y
 * correspond à 3, alors le résultat de "x << y" devient "0001"
 */

int main(){
  //taille de mon nombre binaire (nous travaillons sur 32 bits)
  const unsigned short TAILLE = 32;

  //Le nombre entré au clavier
  unsigned int n;

  unsigned int puissance;

  unsigned short i;

  printf("Entrez une valeur pour n: ");
  scanf("%u", &n);


  /*
  * SP 2: décomposition binaire
  *
  * Pour l'Invariant Graphique, on peut représenter le nombre n comme une suite
  * de bits (cfr. Introduction) où le bit de poids est b_TAILLE et le bit de
  * de poids failbe b_0.
  * Soit
  *                                            |
  * n = (b_TAILLE, b_TAILLE-1, ..., b_TAILLE-i,| b_TAILLE-i-1, ..., b_1, b_0)
  *      <------------------------------------>| <------------------------->
  *             déjà affiché à l'écran              encore à afficher
  *
  * Fonction de terminaison: i>0
  */
  i = TAILLE;
  while(i>0){
    //je fais un 'et logique' entre la valeur de n et 1 décalé de i bits vers la gauche.  Cette
    //opération me permet de voir si la puissance courante est inclue dans n sans faire la
    //moindre multiplication.
    if(n & (1 << i))
      printf("1");
    else
      printf("0");

    i--;
  }//fin while - i

  printf("\n");
}//fin programme
