/*
 * Chapitre 6: Modularité du Code
 * Ecriture de Fonctions -- Exercice 8 (renversement de tableau)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

/*
 * Permet d'afficher le contenu d'un tableau à l'écran.
 *
 * Le code de cette procédure a été vu plusieurs fois au cours (et aux séances de TPs).
 */
void affiche_tableau(int tab[], unsigned int n){
    unsigned int i;
    printf("[ ");

    for(i=0; i<n; i++)
        printf("%d ", tab[i]);

    printf("]\n");
}//fin affiche_tab()

/*
 * @pre: t est un tableau valide, n>0
 * @post: r est un tableau de même taille que le tableau passé en arguments mais
 *        dont les éléments sont inversés (le dernier élément du tableau passé
 *        en arguments est le premier du tableau résultat, l'avant-dernier
 *        devient le deuxième, ...)
 */
void reverse(int t[], int r[], unsigned int n){
  unsigned int i=0;

  /*
  * Invariant:
  *
  *       |0         |i         n-1|n
  *       +----------+-------------+
  * r:    |          |             |
  *       +----------+-------------+
  *        <--------> <----------->
  *        déjà          encore à renverser
  *        rempli
  *        avec le sous-tableau t[i+1...n-1]
  *
  *       |0        i|          n-1|n
  *       +----------+-------------+
  * t:    |          |             |
  *       +----------+-------------+
  *        <--------> <----------->
  *        à renverser   déjà renversé dans r
  *
  *
  * Fonction de terminaison: n-i
  *
  */
  while(i<n){
    r[i] = t[n-1-i];
    i++;
  }//fin while - i
}//fin reverse()

int main(){
  int tab[50] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,
    23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,
    46,47,48,49,50};

  int r[50];

  affiche_tableau(tab, 50);

  reverse(tab, r, 50);

  affiche_tableau(r, 50);

  return 0;
}//fin programme
