/*
 * Chapitre 3: Méthodologie
 * Construction par Invariants -- Exercice 1 (somme des entiers pairs)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2020
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  Input: a et b lus au clavier
 *  Output: somme des entiers pairs dans [a,b[ est affichée à l'écran
 *  Objets Utilisés:
 *    a, entier (borne inférieure de l'intervalle)
 *      int a;
 *    b, entier (borne supérieure de l'intervalle)
 *      int b
 *
 * Analyse du Problème:
 *  SP1: lire a & b au clavier
 *  SP2: calculer la somme des entiers pairs dans [a,b[
 *  SP3: afficher la somme à l'écran
 *
 * Enchaînement des SPs:
 *  SP2 -> SP2 -> SP3
 */
int main(){
  int a, b, i;
  int somme = 0;

  //SP1
  printf("Veuillez introduire une valeur pour a et b (b>=a):");
  scanf("%d %d", &a, &b);

  i = a;

  /*
   * SP2
   *
   * Invariant Graphique:
   *
   * Invariant:
   *  0 a a+1     ...  i-1| i i+1        ...        b b+1
   *  - - - - - - - - - - | - - - - - - - - - - - - - - - -> Z
   *    <---------------> | <--------------------->
   *      somme contient       encore à calculer
   *     la somme des pairs
   */
   while(i<b){
     if(i%2==0)
      somme += i;
    i++;
  }//fin while - i

  //SP3
  printf("La somme vaut: %d\n", somme);
}//fin programme
