/*
* Chapitre 5: Structures de Données
* Chaînes de Caractères -- Exercice 3 (palindrome)
*
* @author: Benoit Donnet (ULiège)
* Mise à Jour: Novembre 2018
*/

#include <stdio.h>

/*
* Définition du Problème:
*  - Input: chaîne de max 50 caractères
*  - Output: un message indiquant si la chaîne en entrée est un palindrome ou pas?
*  - Objets Utilisés:
*      N est un entier Naturel.  Il ne doit pas être modifié dans le code.
*        const unsigned short N = 50; (par définition de l'énoncé)
*      chaine est un tableau de caractères.
*        char chaine[N+1];
*
* Analyse du Problème:
*  - SP 1: lire la chaîne au clavier
*  - SP 1: déterminer la taille de la chaîne de caractères
*  - SP 2: déterminer si la chaîne est un palindrome
*
* Enchaînement des SPs:
*  SP1 -> SP2 -> SP3
*/

int main(){
  const unsigned short N=50;
  char chaine[N+1];
  unsigned short debut, fin, lu = 0, est_palindrome;

  //SP1: lire la chaîne de caractères
  printf("Entrez la chaîne de caractères (sans espace): ");
  scanf("%50s", chaine);

  /*
   * SP2: trouver la taille réelle de la chaîne de caractères
   *
   * Inv:
   *          |0         |lu         | N|N+1
	 *          +----------+-----------+--+
	 * chaine:  |          |           |\0|
	 *          +----------+-----------+--+
	 *           <--------> <---------->
   *                          à parcourir
   *            s contient
   *            lu caractères utiles
   *
   * Fonction de Terminaison: N+1-lu
   */
  while(chaine[lu]!='\0')
      lu++;

  /*
   * SP 2: déterminer si c'est un palindrome
   *
   * Idée pour la solution: on va parcourir la chaîne de caractères en étau
   * (cfr. exercice sur le renversement de tableau -- algo4.c)
   *
   * Inv:
   *
   *          |0      |debut  fin|       |lu    | N|N+1
	 *          +-------+----------+-------+------+--+
	 * chaine:  |       |          |       |      |\0|
	 *          +-------+----------+-------+------+--+
   *          <------> <--------> <----->
   *                   à vérifier
   *         vérifié                 vérifié
   *          (est_palindrome)       (est_palindrome)
   *
   * Fonction de terminaison: fin+1-debut
   */

  fin = lu - 1;
  debut = 0;
  est_palindrome=1;
  while(debut<=fin && est_palindrome){
      if(chaine[debut]!=chaine[fin])
          est_palindrome = 0;
      fin--;
      debut++;
  }//fin while

  if(est_palindrome)
    printf("Palindrome.\n");
  else
    printf("Pas un palindrome\n");
}//fin programme
