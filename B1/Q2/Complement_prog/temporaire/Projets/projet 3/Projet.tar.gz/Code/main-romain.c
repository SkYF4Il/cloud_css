/**
 * \file main-romain.c
 * \brief Programme principal pour la conversion d'un nombre romain
 * \author Benoit Donnet, Simon Liénardy -- Université de Liège (ULiège)
 * \version 0.1
 * \date 03/04/2020
 *
 * Programme principal.  Contiens les exemples de l'énoncé.
 */

#include <stdio.h>
#include <stdlib.h>

#include "romain.h"

int main(){
  char nbr1[] = "XVI"; 
  char nbr2[] = "XIV"; 
  char nbr3[] = "DIX";
  char nbr4[] = "MMMMCMXCIX";
  char nbr5[] = "MMMMDCCCLXXXVIII";

  unsigned int x = romain_rec(nbr1, 3);
  printf("%s = %u\n", nbr1, x);
  x = romain_rec(nbr2, 3);
  printf("%s = %u\n", nbr2, x);
  x = romain_rec(nbr3, 3);
  printf("%s = %u\n", nbr3, x);
  x = romain_rec(nbr4, 10);
  printf("%s = %u\n", nbr4, x);
  x = romain_rec(nbr5, 16);
  printf("%s = %u\n", nbr5, x);

  return EXIT_SUCCESS;
}//fin programme
