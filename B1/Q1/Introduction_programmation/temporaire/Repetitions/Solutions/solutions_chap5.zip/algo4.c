/*
* Chapitre 5: Structures de Données
* Algo. tableaux -- Exercice 4 (renversement tableau bis)
*
* @author: Benoit Donnet (ULiège)
* Mise à Jour: Novembre 2018
*/

#include <stdio.h>
#include <stdlib.h> //=> pour la génération aléatoire

/*
* Définition du Problème:
*  - Input: tableau à N valeurs entières
*  - Output: affichage à l'écran du tableau renversé
*  - Objets Utilisés:
*      N est un entier Naturel.  Il ne doit pas être modifié dans le code
*        const unsigned N = 20;
*      tab est un tableau d'entiers
*        int tab[N];
*
* Analyse du Problème:
*  - SP 1: remplissage du tableau {tab}
*  - SP 2: renversement du tableau
*  - SP 3: permutation de 2 valeurs du tableau
*  - SP 4: affichage de {renverse}
*
* Enchaînement des SPs:
*  SP1 -> (SP3 \inclus_dans SP2) -> SP4
*/

int main(){
  const unsigned short N = 20;

  int tab[N];

  unsigned short i, j;
  int tmp;

  /*
   * SP 1: remplissage du tableau.
   * Pour l'exercice, nous allons générer aléatoirement des valeurs entre 0 et 9.
   *
   * Inv:
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          rempli       encore à remplir
	 *        avec des valeurs
   *        \in [0, 9]
   *
   * Fonction de terminaison: N-i
   */
  i = 0;
  while(i<N){
    tab[i] = rand()%10;
    i++;
  }//fin while - i

  /*
   * SP 2: renversement du tableau.
   * L'idée de la solution est assez simple.  On va parcourir le tableau tab
   * en étau, i.e., du début vers la fin (indice i) et, en même temps, de la
   * fin vers le début (indice j).  A chaque étape, on permute (SP3) la valeur
   * courante à l'indice i avec la valeur courante à l'indice j.
   *
   * Inv:
   *       |0      |i        j|      N-1|N
	 *       +-------+----------+---------+
	 * tab:  |       |          |         |
	 *       +-------+----------+---------+
   *        <-----> <--------> <------->
   *                à renverser
   *         renversé            renversé
   *        en fin de tab        en début de tab
   *
   * Fonction de terminaison: j-i
   * Complexité: O(N/2)
   */
  i = 0;
  j = N-1;
  while(i < j){
      //SP 3: permutation des indices i et j du tableau
      tmp = tab[i];
      tab[i] = tab[j];
      tab[j] = tmp;

      //on avance i, on recule j
      i++;
      j--;
  }//fin while

  /*
   * SP 3: affichage du tableau renversé
   *
   * Inv:
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *       <---------> <----------->
   *         affiché     encore à afficher
   *         à l'écran
   *
   * Fonction de terminaison: N-i
   */
  printf("[ ");
  i = 0;
  while(i<N){
    printf("%d ", tab[i]);
    i++;
  }//fin while - i
  printf("]\n");
}//fin programme
