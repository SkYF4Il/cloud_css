/*
 * Chapitre 2: Structures de Contrôle
 * Itérations -- Exercice 3 (factorielle)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  int f = 1, n;

  printf("Entrez une valeur pour n: ");
  scanf("%d", &n);

  /*
  * 4 questions:
  *  1. compteur et initialisation?
  *     n (valeur donnée par l'utilisateur)
  *  2. nombre de tours de boucle?
  *     n-1
  *  3. gardien de boucle?
  *     n > 0
  *  4. corps de boucle?
  *     produit cumulatif pour les valeurs intermédiares de la factorielle
  *     décrémenter le compteur n
  */
  while(n > 0){
    f *= n;
    n--;
  }//fin while - n

  printf("%d! = %d\n", n, f);
}//fin programme
