/*
 * Chapitre 5: Modularité du Code
 * Ecriture de Fonctions -- Exercice 7 (données décroissantes)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <assert.h>

/*
 * @pre: t est un tableau valide, n>0
 * @post: retourne 1 si les données du tableau t sont en ordre strictement
 *        décroissant.  -1 sinon.
 */
int ordonne(int t[], unsigned int n){
  assert(t!=NULL);
  unsigned int i;
  int ordonne = 1;

  /*
  * Invariant:
  *       |0         |i         n-1|n
  *       +----------+-------------+
  * t:    |          |             |
  *       +----------+-------------+
  *        <--------> <----------->
  *          ordonné       encore
  *        par ordre     à vérifier
  *        croissant
  *        (ordonne == 1)
  *
  * Fonction de terminaison:  n-1-i
  */
  for(i=0; i<n-1 && ordonne!=-1; i++){
    if(t[i]>=t[i+1])
      ordonne = -1;
  }//fin for - i

  return ordonne;
}//fin ordonne()

int main(){
  int tab[50] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,
    23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,
    46,47,48,49,50};

  printf("%u\n", ordonne(tab, 50));

  return 0;
}//fin programme
