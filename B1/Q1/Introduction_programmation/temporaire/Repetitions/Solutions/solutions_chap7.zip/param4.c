/*
 * Chapitre 7: Pointeurs
 * Ecriture de Fonctions -- Exercice 4 (somme et différence de 2 nombres)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <assert.h>

/*
 * Application du passage de paramètres par adresse de façon à retourner,
 * depuis une même fonction/procédure, plusieurs résultat (ici la somme et la
 * différence de deux nombres
 */
void calcul(int a, int b, int *somme, int *difference){
  assert(somme!=NULL && difference!=NULL);

  *somme = a+b;
  *difference = a-b;
}//fin calcul()

int main(){
  int a=12, b=45;
  int somme, difference;
  
  calcul(a, b, &somme, &difference);

  printf("a+b=%d, a-b=%d\n", somme, difference);

  return 0;
}//fin programme
