/*
 * Chapitre 5: Structures de Données
 * Algo. tableaux -- Exercice 1 (Distance de Hamming)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  - Input: deux tableaux d'entiers
 *  - Output: distance de hamming entre les tableaux
 *  - Objets Utilisés:
 *      U, un tableau d'entiers
 *      V, un tableau d'entiers
 *      N, la taille des tableaux U et V
 *
 * Analyse du Problème:
 *  - SP 1: remplissage du tableau {U}
 *  - SP 2: remplissage du tableau {V}
 *  - SP 3: calcul de la distance de Hamming entre {U} et {V}
 *  - SP 4: affichage de la distande de Hamming entre {U} et {V}
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3 -> SP4
 */

int main(){
  const unsigned short N = 10;

  int U[N];
  int V[N];

  unsigned int distance = 0;
  unsigned short i;

  /*
   * SP 1: remplir le tableau {U} avec {N} valeurs entières lues au
   * clavier.
   *
   * Invariant:
	 *
	 *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * U:    |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          rempli       encore
	 *        au clavier    à remplir
	 *
	 * Fonction de terminaison: N-i
   */
  i = 0;
  while(i<N){
    printf("Entez la %deme valeur du tableau: ", i+1);
    scanf("%d", &U[i]);
    i++;
  }//fin while - i

  /*
   * SP 2: remplir le tableau {V} avec {N} valeurs entières lues au
   * clavier.
   *
   * Invariant:
	 *
	 *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * V:    |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          rempli       encore
	 *        au clavier    à remplir
	 *
	 * Fonction de terminaison: N-i
   */
  i = 0;
  while(i<N){
    printf("Entez la %deme valeur du tableau: ", i+1);
    scanf("%d", &V[i]);
    i++;
  }//fin while - i

  /*
   * SP 3: Calcul de la distance de Hamming entre U et V
   *
   * Inv:
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * V:    |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
   *                      à explorer
   *         distance de
   *         hamming déjà calculée
   *
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * V:    |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
   *                      à explorer
   *         distance de
   *         hamming déjà calculée
   *  distance = (U[0]!=V[0] + ... +U[i-1]!=V[i-1])
   *
   * Fonction de terminaison: N-i
   */
  i = 0;
  while(i<N){
    if(U[i]!=V[i])
      distance++;
    i++;
  }//fin while - i

  //SP 4: affichage à l'écran de la distance de Hamming entre {U} et {V}
  printf("La distance de Hamming entre U et V est: %u\n", distance);
}//fin programme
