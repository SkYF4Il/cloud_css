/*
 * Chapitre 5: Structures de Données
 * Tableaux Uni. -- Exercice 6 (crible d'Erastothène)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  - Input: tableau à N valeurs entières de 1 à N
 *  - Output: les nombres premier de 1 à N ont été affichés
 *  - Objets Utilisés:
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsigned short N = 500; (car valeur donnée par l'énoncé)
 *      tab est un tableau d'entiers
 *        int tab[N];
 *
 * Analyse du Problème:
 *  - SP 1: remplissage du tableau
 *  - SP 2: affichage des nombres premiers
 *  - SP 3: élimination des multiples de tab[i] dans tab[i+1 ... N-1]
 *
 * Enchaînements des SPs:
 *  SP1 -> (SP3 \inclus_dans SP2)
 */

 int main(){
   const unsigned short N = 500;

   int tab[N];

   unsigned short i, j;

   /*
   * SP 1: remplissage du tableau.  Le tableau sera rempli comme suit:
   * for_all i, 0<=i<=N-1, tab[i] = i
   *
   * Invariant:
   *
   *       |0         |i         N-1|N
   *       +----------+-------------+
   * tab:  |          |             |
   *       +----------+-------------+
   *        <--------> <------------>
   *          rempli       à remplir
   *          de sorte que
   *          tab[j] = j, 0 <= j <= i-1
   *
   * Fonction de terminaison: N-i
   */
   i = 0;
   while(i< N){
     tab[i] = i;
     i++;
   }//fin while - i

   /*
   * Crible d'Eratosthène.
   * Comme notre tableau commence avec les valeurs 0 et 1 dans les 2
   * premiers indices, on va commencer à partir de la 3ème case du tableau
   */

   /*
   * SP2: affichage des nombres premiers.
   *
   * Inv:
   *       |0         |i         N-1|N
   *       +----------+-------------+
   * tab:  |          |             |
   *       +----------+-------------+
   *                   <------------>
   *                   encore à afficher
   *        <-------->
   *       les nombres
   *       premiers tab[0...i-1]
   *       ont été affichés à
   *       l'écran
   *
   * Fonction de terminaison: N-i
   */
   printf("%d\n", tab[1]);
   i = 2;
   while(i<N){
     if(tab[i]!=0){
       printf("%d\n", tab[i]);

       /*
       * SP 3: élimination des multiples de tab[i]
       *
       * Inv:
       *
       *       |0         |i     |j   N-1|N
       *       +----------+------+-------+
       * tab:  |          |              |
       *       +----------+------+-------+
       *                          <------>
       *                   <---->
       *                    les multiples de tab[i]
       *                    dans tab[i+1 ... j-1] ont
       *                    été remplacés par 0
       */
       j = i+1;
       while(j<N-1){
         if(tab[j]%i==0)
          tab[j] = 0;
         j++;
       }//fin while - j
     }//fin if
     i++;
   }//fin while - i
 }//fin programme
