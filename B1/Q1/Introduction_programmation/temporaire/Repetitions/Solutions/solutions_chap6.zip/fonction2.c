/*
 * Chapitre 6: Modularité du Code
 * Ecriture de Fonctions -- Exercice 2 (aire triangle)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <assert.h>

/*
 * Définition du Problème:
 *  - Input: base et hauteur du triangle, lus au clavier
 *  - Output: l'aire du triangle est affichée à l'écran
 *  - Objets Utilisés:
 *    base, un nombre flottant représentant la base du triangle.
 *      float base;
 *    hauteur, un nombre flottant représentant la hauteur du triangle.
 *      float hauteur;
 *
 * Analyse du Problème:
 *  - SP1: lecture au clavier (base et hauteur)
 *  - SP2: calcul de l'aire du triangle
 *  - SP3: affichage de l'aire du triangle
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3
 *
 * Le SP2 peut être "sorti" du programme principal pour en faire une fonction.
 */

/*
 * SP2
 * Définition du Problème:
 *  - Input: deux nombres positifs représentants la base/hauteur du triangle
 *  - Output: l'aire du triangle
 *  - Objets Utilisés:
 *    base, hauteur, deux flottants positifs
 *      paramètres formels de la fonction
 *
 * @pre: base>0, hauteur>0
 * @post: aire du triangle
 */
float aire_triangle(float base, float hauteur){
  assert(base > 0 && hauteur > 0);

  float aire = (base * hauteur)/2;

  return aire;
}//fin aire_triangle()

int main(){
  float base, hauteur, aire;

  //SP1: lire les valeurs de base et hauteur
  printf("Entrez la base et la hauteur du triangle: ");
  scanf("%f %f", &base, &hauteur);

  //SP 2: calcul l'aire.
  aire = aire_triangle(base, hauteur);

  //SP3: affichage de l'aire
  printf("L'aire du triangle de hauteur %f et base %f est %f\n", hauteur, base, aire);

  return 0;
}//fin programme
