/*
 * Chapitre 3: Méthodologie
 * Construction par Invariants -- Exercice 2 (vitesse d'un mobile)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  - Input: position et vitesse initiales du mobile, accélération et temps
 *  - Output: la position du mobile à chaque temps t
 *  - Objets Utilisés:
 *      s0, un réel représentant la position initiale du mobile
 *        float s0;
 *      v0, un réel représentant la vitesse initiale du mobile
 *        float v0;
 *      a, un réel représentant l'accélération du mobile
 *        float a;
 *      t, un naturel représentant le maximum de temps
 *        unsigned int t;
 *
 * Analyse du Problème:
 *  SP1: Lire au clavier les valeurs initiales
 *  SP2: calcul des positions du mobile
 *  SP3: au temps i, afficher la position courante du mobile
 *
 * Enchaînement des Sous-Problèmes:
 *  SP1 -> (SP3 \inclus SP2)
 */

int main(){
  unsigned int i, t;
  float s, s0, v0, a;

  /*
   * SP1: Lecture au clavier des valeurs initiales
   */
  printf("Entrez une valeur pour la position initiale: ");
  scanf("%f", &s0);
  printf("Entrez une valeur pour la vitesse intiale: ");
  scanf("%f", &v0);
  printf("Entrez une valeur pour l'accélération: ");
  scanf("%f", &a);
  printf("Entrez une valeur pour le temps: ");
  scanf("%u", &t);

  s  = s0;
  /*
   * SP2: calcul des différentes positions du mobile
   *
   * Invariant Graphique:
   *
   *   0    5    10         i-5 |  i            t   t+5
   *   |----|----|   ...   --|--|--|    ...   --|----|-----------> temps
   *    <-------------------->  |
   *      la position du mobile
   *      aux temps 0, 5, ..., i-5 a
   *      été calculée dans s
   *
   * Fonction de terminaison: t+5-i+1
   */
  i = 0;
  while(i<=t){
    s = s0 + v0*i + 0.5*a*i*i;
    //SP3
    printf("la position du mobile au temps %d: %f\n", i, s);

    t+=5;
  }//fin while - i

  /*
  * Pour élever au carré la valeur contenue dans une variable (e.g., x),
  * il suffit de multiplier cette variable par elle-même (i.e., x*x).
  *
  * Attention, l'opérateur '^' ne permet pas d'élever à une puissance
  * particulière.  L'opérateur '^' est en fait un opérateur 'bitwise'
  * qui permet de faire le "ou exclusif" (XOR) entre les deux opérandes.
  *
  * Attention, donc, à ne pas confondre les 2.
  */
}//fin programme
