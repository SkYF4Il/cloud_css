#include <assert.h>

#include "romain.h"

/**
 * \fn static unsigned int mapping(char c_romain)
 * \brief Mapping entre un chiffre romain et son équivalent arabe
 *
 * \param c_romain, le chiffre romain
 *
 * \return la représentation décimale du chiffre romain.  0 en cas d'erreur.
 */
static unsigned int mapping(char c_romain){
  switch(c_romain){
    case 'I': return 1;
    case 'V': return 5;
    case 'X': return 10;
    case 'L': return 50;
    case 'C': return 100;
    case 'D': return 500;
    case 'M': return 1000;
    default: return 0;
  }
}//fin mapping()

unsigned int romain_rec(char *chiffres, unsigned int n){
  //VOTRE CODE ICI
  return 0;
}//fin romain_rec()
