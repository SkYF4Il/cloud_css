/*
 * Chapitre 3: Méthodologie
 * Construction par Invariant -- Exercice 5 (approximation d'une racine carrée)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <math.h>

/*
 * Définition du Problème:
 *  - Input: n, le nombre pour lequel il faut approximer la racine carrée,
 *           iter, le nombre d'itérations dans l'approximation
 *  - Output: l'approximation de sqrt(n) est affichée
 *  - Objets Utilisés:
 *    n, un nombre entier positif
 *      unsigned int n;
 *    iter, un nombre entier positif
 *      unsigned int iter;
 *
 * Analyse du Problème:
 *  SP1: lire au clavier les valeurs de n et iter
 *  SP2: approximation de sqrt(n)
 *  SP3: affichage de l'approximation
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3
 */

int main(){
  float racine, suite;
  unsigned int n, i, iter;

  /*
   * SP1: Lecture au clavier
   */
  printf("Entrez la valeur: ");
  scanf("%u", &n);
  printf("Entrez le nombre d'itération: ");
  scanf("%u", &iter);

  /*
   * SP2: Approximation de la racine carrée
   *
   * Invariant (tiré directement de la formule de l'énoncé):
   *  2 <= i <= n+1, suite = (n/Xi-1 + Xi-1)/2
   *
   * Fonction de terminaison: n-i-1
   */
  suite = 1; //le premier terme vaut 1
  i = 2;
  while(i<=n){
    suite = (n/suite + suite)/2;
    i++;
  }//fin while - i

  /*
   * SP3: Affichage du résultat
   */
  racine = sqrt(n);
  printf("%f vs. %f\n", racine, suite);
}//fin programme
