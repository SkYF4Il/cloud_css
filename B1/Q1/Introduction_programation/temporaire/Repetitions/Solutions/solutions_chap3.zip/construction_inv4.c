/*
 * Chapitre 3: Méthodologie
 * Construction par Invariants -- Exercice 4 (produit de 2 naturels)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2020
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  - Input: x, y deux entiers
 *  - Output: le résultat de x * y est affiché à l'écran
 *  - Objets Utilisés:
 *    x, un entier
 *      int x;
 *    y, un entier
 *      int y;
 *
 * Analyse du Problème:
 *  SP1: lecture au clavier des valeurs pour x et y
 *  SP2: multiplication rapide de x par y
 *  SP3: affichage du résultat
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3
 */
int main(){
    int x, y, p=0;

    /*
     * SP1: lecture au clavier
     */
    printf("Entrez les valeurs pour x et y: ");
    scanf("%d %d", &x, &y);

    /*
     * SP3
     * Soient x=a et y=b
     * Invariant (formel):
     *    a*b = p + x*y, y>0
     */
    while(y>0){
      //Inv: a*b = p + x*y, y = (y/2)*2 > 0
      while(!y%2){ //y est pair?
        y /= 2; //pour info, cette instruction est équivalente à y >>= 1;
        //a*b = p + 2x*y
        x *=2; //pour info, cette instruction est équivalente à x <<= 1;
        //a*b = p + x*y
      }//fin while
      //a*b = p + (x-1)*y + y et y>0 et y impair
      p += x;
      //a*b = p + x*y-1 et y impair
      y--;
      //a*b = p + x*y
    }//fin while

    printf("%d\n", p);
}//fin programme
