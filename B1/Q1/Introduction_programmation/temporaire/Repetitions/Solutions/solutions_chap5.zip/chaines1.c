/*
* Chapitre 5: Structures de Données
* Chaînes de Caractères -- Exercice 1 (occurrences de 'e')
*
* @author: Benoit Donnet (ULiège)
* Mise à Jour: Novembre 2018
*/

#include <stdio.h>

/*
* Définition du Problème:
*  - Input: une chaîne de N caractères utiles
*  - Output: nombre de 'e' dans la chaîne de caractères
*  - Objets Utilisés:
*      N est un entier Naturel.  Il ne doit pas être modifié dans le code.
*        const unsigned short N = 133; (par définition de l'énoncé)
*      chaine est un tableau de caractères.
*        char chaine[N];
*
* Analyse du Problème:
*  - SP 1: lire la chaîne de caractères au clavier.
*  - SP 2: comptage des 'e' dans {chaine}
*  - SP 3: affichage du résultat à l'écran.
*
* Enchaînement des SPs:
*  SP1 -> SP2 -> SP3
*/

int main(){
  const unsigned short N = 132;
  const char E = 'e';
  char chaine[N+1]; //N caractères utiles + le caractère de terminaison ('\0')
  unsigned short i, nb_car = 0;

  //lire la chaîne au clavier
  printf("Entrez la chaîne de caractères (sans espace): ");
  scanf("%132s", chaine);

  /*
   * SP 1: recherche (et comptage) de 'e' dans {chaine}
   *
   * Idée: il suffit de parcourir la chaîne de caractères et de comparer chaque caractère.
   * Dès qu'on rencontre une occurence du caractère 'caractere', on incrémente le compteur
   * d'une unité. Attention, la fin de la chaîne de caractères n'est pas donné par la
   * constante N+1 mais bien par le caractère nul '\0' (la chaîne de caractères fait AU MAXIMUM
   * N caractères utiles)
   *
   * Invariant:
	 *
	 *          |0         |i          | N|N+1
	 *          +----------+-----------+--+
	 * chaine:  |          |           |\0|
	 *          +----------+-----------+--+
	 *           <--------> <---------->
	 *              nb_car      encore à explorer
   *          vaut le nombre
   *          d'occurences du caractère
   *          {E} dans chaine[0...i-1]
	 *
   * Fonction de terminaison: N+1-i
   */
  for(i=0; chaine[i]!='\0'; i++){
      if(chaine[i]==E)
          nb_car++;
  }//fin for - i

  printf("Nombre de 'e': %hu\n", nb_car);
}//fin programme
