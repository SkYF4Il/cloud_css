/*
* Chapitre 5: Structures de Données
* Chaînes de Caractères -- Exercice 2 (afficher à l'envers une chaîne de caractères)
*
* @author: Benoit Donnet (ULiège)
* Mise à Jour: Novembre 2018
*/

#include <stdio.h>

/*
* Définition du Problème:
*  - Input: une chaîne de max 30 caractères
*  - Output: la chaîne de caractères est affichée à l'envers
*  - Objets Utilisés:
*      N est un entier Naturel.  Il ne doit pas être modifié dans le code.
*        const unsigned short N = 30; (par définition de l'énoncé)
*      s est un tableau de caractères.
*        char s[N+1];
*
* Analyse du Problème:
*  - SP 1: lire la chaîne s au clavier
*  - SP 2: déterminer la longueur utile de la chaîne de caractères
*  - SP 3: retourner la chaîne
*
* Enchaînement des SPs:
*  SP1 -> SP2 -> SP3
*/

int main(){
  //dimension de la chaîne de caractères
  const unsigned short N = 30;

  //la chaîne de caractères
  char s[N+1];

  unsigned short lu, i;

  //SP 1: lecture de s au clavier
  printf("Entrez la chaîne de caractères (max. 30 caractères): ");
  scanf("%s", s);

  /*
   * SP 2: déterminer la longueur utile de la chaîne de caractères.
   *
   * L'utilisateur a entré, au plus, 30 caractères.  On va stocker dans 'lu' la
   * longueur utile (i.e., le nombre de caractères effectivement entré).
   *
   * Inv:
   *
	 *          |0         |lu         | N|N+1
	 *          +----------+-----------+--+
	 *      s:  |          |           |\0|
	 *          +----------+-----------+--+
	 *           <--------> <---------->
   *                          à parcourir
   *            s contient
   *            lu caractères utiles
   *
   * Fonction de Terminaison: N+1-lu
   */
  lu = 0;
  while(s[lu]!='\0')
      lu++;

  /*
   * SP 3: retourner la chaîne.
   * Il suffit de parcourir la chaîne à reculons, à partir de 'lu-1'
   *
   * Inv:
   *
   *          |0        i|      |lu   | N|N+1
	 *          +----------+------+-----+--+
	 *      s:  |          |      |     |\0|
	 *          +----------+------+-----+--+
   *          <---------> <---->
   *            à afficher
   *                        déjà affiché
   *
   * Fonction de terminaison: lu-i
   */
  i = lu-1;
  while(i>=0){
    printf("%c", s[i]);
    i--;
  }//fin while - i
  printf("\n");
}//fin programme
