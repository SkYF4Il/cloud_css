/*
 * Chapitre 5: Structures de Données
 * Tableaux Multi. -- Exercice 2 (Mise à 0 de la diagonale d'une matrice)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

/*
 * Définition du Problème
 *  - Input: matrice d'entiers de dimension NxN
 *  - Output: affichage de la matrice avec la diagonale à 0
 *  - Objets Utilisés:
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code.
 *        const unsigned short N = 3;
 *      matrice est une matrice (carrée) de valeurs entières.
 *        int matrice[N][N];
 *
 * Analyse du Problème:
 *  - SP 1: remplissage de la matrice.  On peut, bien entendu, décomposer ce SP
 *      en deux SPs (un pour la gestion des lignes, un autre pour le remplissage des
 *      colonnes de la ligne courante.
 *  - SP 2: affichage de la matrice.  On peut, bien entendu, décomposer
 *      ce SP en deuc SPs (un pour l'énumération des lignes, un autre pour l'affichage des
 *      colonnes de la ligne courante).
 *  - SP 3: mise de la diagonale à 0
 *
 * Enchaînement des SPs:
 *  SP 1 -> SP2 -> SP3 -> SP2
 */

int main(){
  //dimension de la matrice carrée
  const unsigned short N = 3;

  //la matrice
  int matrice[N][N];

  unsigned short i, j;

  /*
   * SP 1: remplissage de la matrice.
   *
   * Inv 1: 0<=i<=N, j'ai déjà lu clavier les (i) première lignes de ma matrice.
   *
   * Fonction de Terminaison: N-i
   */
  for(i=0; i<N; i++){
    /*
     * Invariant:
     * 0<=j<=N, 0<=i<N, j'ai déjà lu au clavier les (j) première colonne de la
     *        ligne d'indice i.
     *
     * Fonction de terminaison: N-j
     */
    for(j=0; j<N; j++){
      printf("Elément[%hu][%hu] : ", i, j);
      scanf("%d", &matrice[i][j]);
    }//fin for - j
  }//fin for - i

  /*
   * SP2: affichage de la matrice
   *
   * Invariant(s): cfr. Exercice 1 sur les tableaux multidimensionnels
   */
  printf("Matrice donnée :\n");
  for (i=0; i<N; i++){
    for(j=0; j<N; j++)
      printf("%3d", matrice[i][j]);
    printf("\n");
  }//fin for - i

  /*
   * SP3: mise à zéro de la diagonale principale
   * Invariant:
   *               |0                    N-1|N
   *              -+------------------------+ ––
   *              0|                        |   |
   *               |                        |   | diagonale remplie de 0
   *               ...        ...         ...   |
   *  matrice:  i-1|                        | __|
   *            --------------------------------
   *              i|                        | --
   *               ...        ...         ...   |
   *            N-1|                        |   |  encore à remplir
   *              -+------------------------+ ––
   *              N
   *
   * Inv: 0<=i<=N, pour tout k, 0<=k<i<=N, matrice[k][k] = 0
   */
  for(i=0; i<N; i++)
    matrice[i][i]=0;

  /*
   * SP2: affichage de la matrice
   *
   * Invariant(s) & Fonction(s) de Terminaison:
   *    cfr. Exercice 1 sur les tableaux multidimensionnels
   */
  printf("Matrice donnée :\n");
  for (i=0; i<N; i++){
    for(j=0; j<N; j++)
      printf("%3d", matrice[i][j]);
    printf("\n");
  }//fin for - i
}//fin programme
