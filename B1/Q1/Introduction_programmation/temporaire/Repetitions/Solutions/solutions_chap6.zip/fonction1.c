/*
 * Chapitre 6: Modularité du Code
 * Ecriture de Fonctions -- Exercice 1 (moyenne de 3 nombres)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  - Input: 3 nombres entiers, lus au clavier
 *  - Output: la moyenne des 3 nombres
 *  - Objets Utilisés:
 *    a, b, c, des entiers
 *      int a, b, c;
 *
 * Analyse du Problème:
 *  - SP 1: lecture au clavier de a, b, c
 *  - SP 2: calcul de la moyenne
 *  - SP 3: affichage du résultat
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3
 *
 * Le SP2 peut être "sorti" du programme principal pour en faire une fonction.
 */

/*
 * SP2: calcul de la moyenne
 * Définition du Problème
 *  - Input: a, b, c
 *  - Output: moyenne de a, b, c
 *  - Objets Utilisés:
 *    a, b, c des entiers
 *      paramètres formels de la fonction
 *
 * @pre: /
 * @post: moyenne de a, b, c
 */
double moyenne(int a, int b, int c){
  return (a+b+c)/3;
}//fin moyenne()

int main(){
  int a, b, c;
  double moy;

  //SP1: lire les valeurs de a, b, c
  printf("Entrez les différentes valeurs: \n");
  scanf("%d", &a);
  scanf("%d", &b);
  scanf("%d", &c);

  //SP2: calcul de la moyenne
  moy = moyenne(a, b, c);

  //SP3: affichage du résultat
  printf("La moyenne est de: %lf\n", moy);

  return 0;
}//fin programme
