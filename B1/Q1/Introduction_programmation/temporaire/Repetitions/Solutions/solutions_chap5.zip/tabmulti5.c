/*
 * Chapitre 5: Structures de Données
 * Tableaux Multi. -- Exercice 5 (Somme de 2 matrices)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

/*
 * Définition du Problème
 *  - Input: 2 matrices d'entiers, de dimension N*M
 *  - Output: affichage de la matrice C = A + B
 *  - Objets Utilisés:
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code.
 *        const unsigned short N = 10;
 *      M est un entier Naturel.  Il ne doit pas être modifié dans le code.
 *        const unsigned short M = 10;
 *      A est une matrice de valeurs entières.
 *        int A[N][M];
 *      B est une matrice de valeurs entières.
 *        int B[N][M];
 *
 * Analyse du Problème:
 *  - SP 1: remplissage de la matrice {A} (possibilité de raffiner en 2 SPs)
 *  - SP 2: remplissage de la matrice {B} (possibilité de raffiner en 2 SPs)
 *  - SP 3: calcul de {C} = {A} + {B} (possibilité de raffiner en 2 SPs)
 *  - SP 4: affichage de la matrice {C} (possibilité de raffiner en 2 SPs)
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3 -> SP4
 */


 int main(){
   const unsigned short N = 10;
   const unsigned short M = 10;
   int A[N][M];
   int B[N][M];
   int C[N][M];
   unsigned short i,j;

   /*
   * SP 1: remplissage de la matrice A.
   *
   * Invariant:
   *   0<=i<=N, j'ai déjà lu clavier les (i) première lignes de la matrice A.
   *
   * Fonction de Terminaison: N-i
   */
   for(i=0; i<N; i++){
     /*
     * Invariant:
     * 0<=j<=M, 0<=i<N, j'ai déjà lu au clavier les (j) première colonne de la
     *        ligne d'indice i de la matrice A.
     *
     * Fonction de Terminaison: M-j
     */
     for(j=0; j<M; j++){
       printf("Elément[%hu][%hu] : ", i, j);
       scanf("%d", &A[i][j]);
     }//fin for - j
   }//fin for - i

   /*
   * SP 1: remplissage de la matrice B.
   *
   * Invariant:
   *   0<=i<=N, j'ai déjà lu clavier les (i) première lignes de la matrice B.
   *
   * Fonction de Terminaison: N-i
   */
   for(i=0; i<N; i++){
     /*
     * Invariant:
     * 0<=j<=M, 0<=i<N, j'ai déjà lu au clavier les (j) première colonne de la
     *        ligne d'indice i de la matrice B.
     *
     * Fonction de Terminaison: M-j
     */
     for(j=0; j<M; j++){
       printf("Elément[%hu][%hu] : ", i, j);
       scanf("%d", &B[i][j]);
     }//fin for - j
   }//fin for - i

   /*
   * SP 3: C = A + B
   *
   * L'invariant peut facilement être tiré de la formule donnée dans l'énoncé.
   */
   for(i=0; i<N; i++){
     for(j=0; j<M; j++){
       C[i][j] = A[i][j] + B[i][j];
     }//fin for - j
   }//fin for - i

   /*
   * SP 4: affichage du résultat
   *
   * Invariant(s) & Fonction(s) de Terminaison:
   *    cfr. Exercice 1 sur les tableaux multidimensionnels
   */
   printf("Matrice C :\n");
   for(i=0; i<N; i++){
     for(j=0; j<M; j++)
      printf("%3d", C[i][j]);
     printf("\n");
   }//fin for - i
}//fin programme
