/*
 * Chapitre 6: Modularité du Code
 * Ecriture de Fonctions -- Exercice 4 (le nombre E)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <assert.h>

/*
 * Définition du Problème:
 *  - Input: le nombre d'itérations pour l'approximation en série
 *  - Output: approximation du nombre e affichée à l'écran
 *  - Objets Utilisés:
 *    precision, le nombre d'itérations de l'approximation.  Ne peut être négatif
 *      unsigned int precision;
 *
 * Analyse du Problème:
 *  - SP1: lecture au clavier du nombre d'itérations
 *  - SP2: calcul de factorielle
 *  - SP3: apprixmation de e, étape par étape
 *  - SP4: affichage du résultat
 *
 * Enchaînement des SPs:
 * SP1 -> (SP2 \inclus SP3) -> SP4
 *
 * Les SP2 et SP3 sont externalisés dans des fonctions.
 */


/*
 * SP2: calcul de factorielle n
 * Définition:
 *  - Input: n >= 0
 *  - Output: la factorielle de n
 *  - Objets Utilisés:
 *    n, la valeur pour laquelle calculer la factorielle
 *      paramètre formel de la fonction
 *
 * @pre: n>=0
 * @post: n!
 */
int factorielle(int n){
  assert(n >= 0);

  int i, fact = 1;

  /*
   * Invariant: 1 <= i <= n+1, fact = (i-1)!
   *
   * Fonction de terminaison: n-i+1
   */
  for(i=1; i<=n; i++)
    fact *= i;

  return fact;
}//fin factorielle()

/*
 * SP3: approximation de e
 * Définition du Problème:
 *  - Input: precision, le nombre d'itérations dans l'approximation
 *  - Output: une approximation du nombre e
 *  - Objets Utilisés:
 *    precision, le nombre de tours
 *      paramètre formel de la fonction
 *
 * @pre: /
 * @post: une approximation du nombre e
 */
double approximation_e(unsigned int precision){
  double e = 0.0;
  int k;

  /*
   * Invariant:
   *  0  1  2        k-1 k        precision
   *  |--|--|-- ... --|--|-- ... --|-----------------------> N
   *   <------------->
   *    e est approximé
   *    pour k termes
   *
   * Fonction de terminaison: precision - k
   */
  k = 0;
  while(k<precision){
    //SP2
    e += 1/factorielle(k);
    k++;
  }//fin while

  return e;
}//fin approximation_e()

int main(){
  unsigned int precision;
  int k;
  double e=0.0;

  //SP1
  printf("Entrez une valeur pour le nombre d'itérations: ");
  scanf("%u", &precision);

  //SP3
  e = approximation_e(precision);

  //SP4
  printf("la valeur de e: %f\n", e);

  return 0;
}//fin programme
