/*
 * Chapitre 5: Structures de Données
 * Enregistrement -- Exercice 6 (structure de données pour l'état civil)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

typedef struct{
  unsigned short jour;
  unsigned short mois;
  unsigned short annee;
}Date;

typedef struct{
  char nom[31];
  Date date_naissance;
  char ville[31];
  unsigned short codepostal;
}EtatCivil;

int main(){
  /*
   * Uniquement la déclaration de la structure et la déclaration des différentes
   * variables.
   * Le reste est facilement codable sur base des exercices précédents.
   */

  //Dimension du tableau
  const unsigned short N = 50;

  //le tableau
  EtatCivil tab[N];

  int i;
}//fin programme
