/*
 * Chapitre 3: Méthodologie
 * Code Mystère -- Exercice 1 (logarithme binaire de n)
 *
 * @author: Benoit Donnet (ULiege)
 * Mise à Jour: Novembre 2018
 */

 #include <stdio.h>

 int main(){
   int n, k=-1, p=1;

   //Note: lbe(0) = -1

   //SP1
   printf("Entrez une valeur pour n: ");
   scanf("%d", &n);

   //SP2
   while(p<=n){
     k++;
     p = 2*p;
   }//fin while

   //SP3
   printf("lbe(%d) = %d\n", n, k);
 }//fin programme
