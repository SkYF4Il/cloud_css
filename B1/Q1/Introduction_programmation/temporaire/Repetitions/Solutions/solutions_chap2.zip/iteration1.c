/*
 * Chapitre 2: Structures de Contrôle
 * Itérations -- Exercice 1 (table de multiplication)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  unsigned int entier;
  unsigned int i;

  printf("Entrez un entier: ");
  scanf("%u", &entier);

  printf("Table de multiplication de %d:\n", entier);

  /*
   * 4 questions:
   *  1. compteur et initialisation?
   *      i = 1
   *  2. nombre de tours de boucle?
   *      10 (une table de multiplication standard va jusque 10)
   *  3. gardien de boucle?
   *      i<=10
   *  4. corps de boucle?
   *      afficher i*entier
   *      incrémenter le compteur i
   */
  for(i=1; i<=10; i++)
    printf("\t%u x %u = %u\n", i, entier, i*entier);
}//fin programme
