/*
 * Chapitre 5: Structures de Données
 * Enregistrement -- Exercice 4 (point)
 *
 * @author: Benoit Donnet (ULg)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

typedef struct{
  int num;
  float x;
  float y;
}Point;

int main(){
  //Dimension du tableau
  const unsigned short N = 10;

  //tableau de structure
  Point tab[N];

  unsigned short i;

  /*
   * SP 1: remplissage du tableau
   *
   * Inv:
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          rempli       encore
	 *        au clavier    à remplir
	 *
	 * Fonction de terminaison: N-i
   */
  for(i=0; i<N; i++){
      printf("Entrez les %dème valeurs: ", i+1);
      scanf("%d %f %f", &tab[i].num, &tab[i].x, &tab[i].y);
  }//fin for - i

  /*
   * SP 2: affichage du contenu du tableau
   *
   * Inv:
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          affiché       encore
	 *        à l'écran    à afficher
	 *
	 * Fonction de terminaison: N-i
   */
  for(i=0; i<N; i++)
      printf("%d %f %f\n", tab[i].num, tab[i].x, tab[i].y);
}//fin programme
