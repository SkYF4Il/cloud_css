/*
 * Chapitre 2: Structures de Contrôle
 * Conditions -- Exercice 3 (affichage par ordre croissant)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  double a, b, c, max;

  printf("Entrez trois nombres réels : ");
  scanf("%f %f %f", &a, &b, &c);

  if(a < b)
    max = b;
  else
    max = a;

  if(max < c)
    max = c;

  printf("Le maximum des trois nombres est %f\n", max);
}//fin programme
