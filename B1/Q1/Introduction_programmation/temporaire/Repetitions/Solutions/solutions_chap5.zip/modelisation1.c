/*
 * Chapitre 5: Structures de Données
 * Modélisation -- Exercice 1
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */


/*
 * Etape 1: Définir les dimensions nécessaires au problème.  On envisage
 *          deux dimensions:
 *      - N: la taille d'une chaîne de caractères, soit 30 caractères +
 *           le caractère de terminaison
 *      - MAX_EMPLOYE: la taille de la société.
 *
 * Les dimensions peuvent être définies, soit comme des macros (solution
 * ayant ma préférence), soit des constantes globales
 *
 * Note: la notion de macro est vue au Chapitre 6
 */
#define N 31
#define MAX_EMPLOYE 100

/*
 * Etape 2: Définir une adresse.
 *
 * Un enregistrement est suffisant.
 */
typedef struct{
  unsigned short numero; //on suppose 2^16 numéro possible par rue
  char nom_rue[N];
  unsigned int code_postal;//un unsigned short en Belgique serait suffisant.  Mais pas en France
  char localite[N];
}Adresse;

/*
 * Etape 3: Définir la situation militaire d'un homme.
 *
 * Ici, clairement, une énumération est le choix le plus pertinent car on va
 * naturellement associé une valeur entière à un nom symbolique représentant
 * la situation de l'homme
 */
typedef enum{
  libere, exempte, reforme, incorporable
}SituationMilitaire;

/*
 * Etape 4: Définir un employé.
 *
 * On va utiliser un enregistrement (car j'ai des types hétérogènes) reprenant les éléments
 * déclarés plus haut.
 *
 * Attention, je vais avoir besoin "d'un marqueur" me permettant de déterminer quel
 * champ utiliser dans mon union.  Je vais donc ajouter un champ "sexe", de type char.
 * Si la valeur du champ est 'M', alors je devrai considérer la situation militaire.  Si c'est
 * 'F', alors le nom de jeune fille
 */
typedef struct{
  char nom[N];
  char prenom[N];
  char sexe;
  SituationMilitaire situation_militaire; //si 'M'
  char nom_jeune_fille[N]; //Si 'F'
}Employe;

/*
 * Etape 5: Définir les employés de la société.
 *
 * Un tableau de MAX_EMPLOYE employés est, ici, suffisant.
 *
 * Il est évident que si on n'avait pas connu la taille de l'entreprise, il aurait fallu
 * passer par un tableau dynamique.  Donc, un enregistrement à 2 champs, la taille du tableau
 * et le tableau en lui-même.
 */
int main(){
    Employe personnel[MAX_EMPLOYE];

    return 0;
}//fin programme()
