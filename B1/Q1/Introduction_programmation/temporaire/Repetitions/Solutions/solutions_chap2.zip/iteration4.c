/*
 * Chapitre 2: Structures de Contrôle
 * Itérations -- Exercice 4 (somme cubes)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  int somme = 0, n;

  printf("Entrez une valeur pour n: ");
  scanf("%d", &n);

  /*
  * 4 questions:
  *  1. compteur et initialisation?
  *     n (valeur introduite au clavier par l'utilisateur)
  *  2. nombre de tours de boucle?
  *     n-1
  *  3. gardien de boucle?
  *     n>0
  *  4. corps de boucle?
  *     faire la somme cumulative intermédiaire des cubes
  *     décrémenter le compteur n
  */
  while(n>0){
    somme += n*n*n;
    n--;
  }//fin while - n

  printf("La somme des cubes des %d premiers entiers est: %d\n", n, somme);
}//fin programme
