/*
 * Chapitre 3: Méthodologie
 * Découpe en sous-problèmes -- Exercice 3 (banque de dépôt et intérêts)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Septembre 2020
 */

#include <stdio.h>

/*
 * Définition du problème:
 *  Input: le montant initial (lu au clavier), le taux d'intérêt (lu au clavier),
 *         le montant cible (lu au clavier)
 *  Output: le nombre d'années nécessaires pour atteindre le montant cible,
 *          affiché à l'écran
 *  Objets Utilisés:
 *      double montant_initial (le montant initial)
 *      unsigned short interet (le taux d'intérêt à appliquer chaque année)
 *      double montant_cible (le montant cible)
 *
 * Analyse:
 *  SP1: lire au clavier le montant initial
 *  SP2: lire au clavier le taux d'intérêt
 *  SP3: lire au clavier le montant cible
 *  SP4: calcul du nombre d'années
 *  SP5: afficher à l'écran le nombre d'années
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3 -> SP4 -> SP5
 */

int main(){
  double montant_initial;
  unsigned short interet;
  double montant_cible;
  unsigned short annee = 0;
  double balance;

  //SP1
  printf("Entrez le montant initial: ");
  scanf("%lf", &montant_initial);

  //SP2
  printf("Entrez le taux d'intérêt de la banque: ");
  scanf("%hu", &interet);

  //SP3
  printf("Entrez le montant cible: ");
  scanf("%lf", &montant_cible);

  /*
  * SP4
  * Construction de la boucle:
  *  1. déclaration du compteur
  *      unsigned short annee = 0;
  *  2. nombre de tours dans la boucle?
  *      inconnu.  C'est le résultat de la variable annee qui nous donnera le nombre de tours dans la boucle
  *  3. gardien de la boucle?
  *      balance < montant_cible
  *  4. corps de la boucle
  *      4.a. dépôt en début d'année
  *      4.b. application du taux d'intérêt
  *      4.c. incrémenter le compteur
  */
  for(annee = 0; balance < montant_cible; annee++){
    //le dépôt en début d'année
    balance += montant_initial;
    balance += balance * interet/100;
  }//fin for

  //SP5
  printf("Nombre d'années: %hu\n", annee);
}//fin programme
