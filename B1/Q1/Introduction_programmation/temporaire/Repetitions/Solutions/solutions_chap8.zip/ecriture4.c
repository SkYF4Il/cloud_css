/*
 * Chapitre 8: Allocation Dynamique
 * Ecriture de Code -- Exercice 4 (La suite u_n)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

/*
 * Définition du Problème:
 *  - Input: n (le nombre d'itérations pour u_n)
 *  - Output: u_n est affiché
 *
 * Analyse du Problème:
 *  - SP1: calcul de u_n et stockage des différentes valeurs dans un tableau
 *  - SP2: affichage d'un tableau
 */

/*
 * SP 1: Calcule la suite u_n et stockage des différentes valeurs dans un tableau
 * @pre: n>=1
 * @post: un tableau contenant les n termes de la suite.
 *        NULL en cas d'erreur.
 */
int *calcule_suite(int n){
    assert(n>=1);

    int u, i;
    int *tab = malloc(n*sizeof(int));
    if(tab==NULL)
        return NULL;

    u = 1;
    /*
     * Invariant:
     *       |0         |i         n-1|n
     *       +----------+-------------+
     * tab:  |          |             |
     *       +----------+-------------+
     *        <--------> <----------->
     *          rempli       encore
     *        avec U_0...i-1 à remplir
     *
     * Fonction de terminaison: n-i
     */
    for(i=1; i<=n; i++){
        tab[i-1] = u;
        u = 3*(u*u)+2*u+1;
    }//fin for - i

    return tab;
}//fin calcule_suite()

/*
 * SP 2: affichage du tableau
 *
 * @pre: n>0, tab est un tableau valide.
 * @post: le contenu de tab est affiché à l'écran
 */
void affiche_tableau(int *tab, int n){
    assert(n>0 && tab!=NULL);

    int i;

    printf("[ ");
    /*
     * Invariant
     *       |0         |i         n-1|n
     *       +----------+-------------+
     * tab:  |          |             |
     *       +----------+-------------+
     *        <--------> <----------->
     *          affiché       encore
     *                      à afficher
     *
     * Fonction de terminaison: n-i
     */
    for(i=0; i<n; i++)
        printf("%d ", tab[i]);
    printf("]\n");
}//fin affiche_tableau()

int main(int argc, char **argv){
  int n, i;

  if(argc!=2){
    printf("Usage: ./main n");
    return -1;
  }

  n = atoi(argv[1]);
  int *tab = calcule_suite(n);
  if(tab==NULL)
    return -1;

  affiche_tableau(tab, n);

  free(tab);

  return 0;
}//fin programme
