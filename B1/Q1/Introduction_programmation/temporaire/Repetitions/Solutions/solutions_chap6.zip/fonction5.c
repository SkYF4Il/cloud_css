/*
 * Chapitre 6: Modularité du Code
 * Ecriture de Fonctions -- Exercice 5 (approximation e^x)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <math.h>
#include <assert.h>

/*
 * Définition du Problème:
 *  - Input: le nombre d'itérations pour l'approximation et x, la valeur
 *           pour laquelle on cherche à calculer e^x
 *  - Output: approximation du nombre e^x
 *  - Objets Utilisés:
 *      precision, un nombre entier naturel
 *        unsigned int precision;
 *      x, une valeur réelle
 *        double x;
 *
 * Analyse du Problème:
 *  - SP1: lecture au clavier des valeurs de precision et x
 *  - SP2: calcul de factorielle
 *  - SP3: calcul de x^k
 *  - SP4: calcul de la série e^x
 *  - SP5: affichage de la valeur estimée de e^x
 *
 * Enchaînement des SPs:
 *  SP1 -> [(SP2 -> SP3) \inclus SP4] -> SP5
 *
 * Les SP2, SP3 et SP4 sont externalisés dans des fonctions.
 * Pour le SP3, on va utiliser pow(double, double), défini dans math.h
 */

 /*
  * SP2: calcul de factorielle n
  * Définition:
  *  - Input: n >= 0
  *  - Output: la factorielle de n
  *  - Objets Utilisés:
  *    n, la valeur pour laquelle calculer la factorielle
  *      paramètre formel de la fonction
  *
  * @pre: n>=0
  * @post: n!
  */
 int factorielle(int n){
   assert(n >= 0);

   int i, fact = 1;

   /*
    * Invariant: 1 <= i <= n+1, fact = (i-1)!
    *
    * Fonction de terminaison: n-i+1
    */
   for(i=1; i<=n; i++)
     fact *= i;

   return fact;
 }//fin factorielle()

/*
 * SP4: calcul de la série e^x
 * Définition:
 *  - Input: x et precision
 *  - Output: une approximation de e^x, avec precision itérations
 *  - Objets Utilisés:
 *    precision, le nombre de tours
 *    x, une valeur réelle
 *      paramètres formels de la fonction
 *
 * @pre:
 * @post: une approximation de e^x
 */
double approximation_e_x(double x, unsigned int precision){
  int k, fact;
  double exp, sum=0.0;

  //Inv: 0<=k<n, sum = x^0/0! + x^1/1! + ... + x^(k-1)/(k-1)!
  /*
   * Invariant:
   *  0  1  2        k-1 k        precision
   *  |--|--|-- ... --|--|-- ... --|-----------------------> N
   *   <------------->
   *    sum contient une
   *    approximation de e^x
   *    pour k termes
   */
  for(k=0; k<precision; k++){
    //SP 2
    fact = factorielle(k);
    //SP 3 => pour résoudre le SP3, je fais appel à la fonction pow() définie dans math.
    exp = pow(x, k);
    sum += (double)exp/fact;
  }//fin for - k

  return sum;
}//fin approximation_e_x()

int main(){
  unsigned int n;
  double x;

  //SP1
  printf("Entrez la valeur de n et de x: ");
  scanf("%u %lf", &n, &x);

  //SP4 & SP5
  printf("e^x en développement de série: %f\n", approximation_e_x(x, n));
  printf("e^x normal: %f\n", pow(M_E, x)); //Note: M_E est une constante définie dans math.h

  return 0;
}//fin programme
