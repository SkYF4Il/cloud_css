/*
 * Chapitre 5: Structures de Données
 * Tableaux Uni. -- Exercice 3 (produit scalaire de 2 vecteurs)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

/*
 * Définition du Problème:
 *  - Input: deux vecteurs à N valeurs entières
 *  - Output: le produit scalaire de X et Y affiché à l'écran
 *  - Objets Utilisés:
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsigned short N = 5; (note: la valeur 5 est donnée à titre indicatif)
 *      X est un tableau d'entiers
 *        int X[N];
 *      Y est un tableau d'entiers
 *        int Y[N];
 *
 * Analyse du Problème:
 *  - SP 1: remplissage du vecteur X
 *  - SP 2: remplissage du vecteur Y
 *  - SP 3: calcul du produit scalaire
 *  - SP 4: affichage du résultat à l'écran
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3 -> SP4
 */

 int main(){
   //taille de mes vecteurs
   const unsigned short N = 5;

   //mon produit scalaire
   int produit = 0;

   //mes vecteurs
   int X[N];
   int Y[N];

   unsigned short i;


   /*
   * SP 1: remplir le vecteur {X} avec {N} valeurs entières lues au
   * clavier.
   *
   * Inv:
   *       |0         |i         N-1|N
   *       +----------+-------------+
   * X:    |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *          rempli       encore
   *        au clavier    à remplir
   *
   * Fonction de terminaison: N-i
   */
   printf("Remplissage du vecteur X: \n");
   for(i=0; i<N; i++){
     printf("Entrez la %dème valeur du vecteur X: ", (i+1));
     scanf("%d", &X[i]);
   }//fin for - i

   /*
   * SP 1: remplir le vecteur {Y} avec {N} valeurs entières lues au
   * clavier.
   *
   * Inv:
   *       |0         |i         N-1|N
   *       +----------+-------------+
   * Y:    |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *          rempli       encore
   *        au clavier    à remplir
   *
   * Fonction de terminaison: N-i
   */
   printf("Replissage du vecteur Y: \n");
   for(i=0; i<N; i++){
     printf("Entrez la %dème valeur du vecteur Y: ", (i+1));
     scanf("%d", &Y[i]);
   }//fin for - i

   /*
   * SP 3: calcul du produit scalaire
   *
   * Inv:
   *       |0         |i         N-1|N
   *       +----------+-------------+
   * X:    |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *          produit       encore
   *         effectué    à multiplier
   *
   *       |0         |i         N-1|N
   *       +----------+-------------+
   * Y:    |          |             |
   *       +----------+-------------+
   *        <--------> <----------->
   *          produit       encore
   *         effectué    à multiplier
   *
   * produit = X[0]*Y[0] + X[1]*Y[1] + ... + X[i-1]*Y[i-1]
   *
   * Fonction de terminaison: N-i
   */
   i = 0;
   while(i<N){
     produit += X[i]*Y[i];
     i++;
   }//fin while -- i

   //SP 4: Affichage du résultat
   printf("Le résultat du produit scalaire est: %d\n", produit);
}//fin programme
