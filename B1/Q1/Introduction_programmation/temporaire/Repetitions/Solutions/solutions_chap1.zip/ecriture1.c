/*
 * Chapitre 1: Blocs, Variables, Instructions Simples
 * Ecriture de Code -- Exercice 1 (prix de hardware)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>

int main(){
  float prix, prixRemise;

  printf("Entrez un prix : ");
  scanf("%f", &prix);

  prixRemise = 0.9 * prix;

  printf("Le prix avec 10 %% de remise est de %f.\n", prixRemise);
}//fin programme
