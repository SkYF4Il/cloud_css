/*
 * Chapitre 5: Structures de Données
 * Tableaux Uni. -- Exercice 8 (notes d'étudiants)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <stdlib.h>  //pour la génération de nombre aléatoire (i.e., les notes)

/*
 * Définition du Problème:
 *  - Input: un tableau de N notes (avec des notes entre 0 et 60)
 *  - Output: statistiques sur les notes (min, max, moyenne) sont affichées à l'écran
 *            ainsi qu'un histogramme donnant la répartition des notes.
 *  - Objets Utilisés:
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsigned short N = 250; (valeur choisie "aléatoirement")
 *      tab est un tableau d'entiers (je considère que les notes sont des valeurs entières)
 *        unsigned short tab[N];
 *      NOTE_MIN est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsigned short NOTE_MIN = 0;
 *      NOTE_MAX est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsigned short NOTE_MAX = 60;
 *
 * Analyse du Problème:
 *  - SP 1: initialisation du tableau de fréquence des notes
 *  - SP 2: remplissage du tableau des notes
 *  - SP 3: calcul de statistiques sur les notes
 *  - SP 4: recherche du maximum dans {notes}
 *  - SP 5: affichage de l'axe des Y de l'histogramme
 *  - SP 6: affichage (éventuellement) d'un bout de colonne de l'histogramme
 *  - SP 7: affichage du domaine de l'histogramme
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3 -> SP4 -> (SP6 \inclus SP5) -> SP7
 */

 int main(){
   //taille des tableaux
   const unsigned short N = 100;
   const unsigned short N_NOTES = 7;

   //les notes min et max
   const unsigned short NOTE_MIN = 0;
   const unsigned short NOTE_MAX = 60;

   //contient les notes
   unsigned short tab[N];

   //contient les fréquences des notes.
   unsigned short notes[N_NOTES];

   //contiendra le maximum du tableau 'notes'
   int maxFreqNotes = -1;

   unsigned short noteMax, noteMin;
   float moyenne;

   unsigned short i, j, somme = 0;

   /*
   * SP 1: initialisation du tableau de fréquence des notes à 0.
   *
   * Inv:
   *
   *        |0         |i   N_NOTES-1|N_NOTES
   *        +----------+-------------+
   * notes: |          |             |
   *        +----------+-------------+
   *         <--------> <----------->
   *                        encore à remplir
   *          déjà rempli
   *          avec des 0
   *
   * Fonction de terminaison: N_NOTES-i
   */
   i = 0;
   while(i<N_NOTES){
     notes[i] = 0;
     i++;
   }//fin while - i

   /*
   * SP 2: remplissage du tableau.
   * Pour l'exerccie, nous allons générer aléatoirement des notes entre 0 et
   * NOTE_MAX.
   *
   *        |0         |i         N-1|N
   *        +----------+-------------+
   * tab:   |          |             |
   *        +----------+-------------+
   *         <--------> <----------->
   *                        encore à remplir
   *          déjà rempli
   *          avec des notes
   *          appartenant à l'intervalle [0; NOTE_MAX]
   */
   i = 0;
   while(i<N){
     tab[i] = rand()%(NOTE_MAX+1);
     i++;
   }//fin while - i

   /*
   * SP3 2: chercher la note max, la note min et calcul intermédiaire pour la moyenne.
   *
   * On va aussi remplir le tableau 'notes'.  On va simplement utiliser la division entière (
   * tab[i]/10) pour obtenir l'indice de la note dans le tableau 'notes'.
   *
   * Exemple: si tab[i] contient la valeur 38, alors tab[i]/10 donne 3.  Hors, notes[3] contient
   * le nombre de notes comprises entre 30 et 39.  On veut donc bien incrémenter d'une unité
   * notes[3].
   *
   * Il est évident qu'on peut considérer le fait de remplir le tableau 'notes' comme un
   * sous-problème à part.  Dans ce cas, le principe de résolution expliqué ici est
   * toujours valable.
   *
   * Invariant:
   *        |0         |i         N-1|N
   *        +----------+-------------+
   * tab:   |          |             |
   *        +----------+-------------+
   *         <--------> <----------->
   *                        encore à explorer
   *            somme vaut
   *            la somme des notes dans tab[0...i-1]
   *            noteMax vaut la note maximum dans tab[0...i-1]
   *            noteMin vaut la note minimum dans tab[0...i-1]
   *            notes[0 ... N_NOTES-1] contient le nombre d'occurences
   *            des notes dans tab[0 ... i-1]
   *
   * Fonction de terminaison: N-i
   */
   noteMin = tab[0];
   noteMax = tab[0];
   somme = tab[0];
   while(i<N){
     //calcul de la somme itérative pour la moyenne
     somme += tab[i];

     //recherche du min et du max
     if(tab[i]>noteMax)
        noteMax = tab[i];
     if(tab[i]<noteMin)
        noteMin = tab[i];

     //mise à jour des fréquences de plages de notes
     notes[tab[i]/10]++;

     i++;
   }//fin while - i

   moyenne = somme/N;

   printf("La moyenne des notes est: %f\n", moyenne);
   printf("La note minimale est: %hu\n", noteMin);
   printf("La note maximale est: %hu\n", noteMax);

   /*
   * SP 4: trouver le maximum dans le tableau 'notes' (ça sera utile pour l'élaboration de
   * l'histogramme)
   *
   * Inv:
   *
   *        |0         |i   N_NOTES-1|N_NOTES
   *        +----------+-------------+
   * notes: |          |             |
   *        +----------+-------------+
   *         <--------> <----------->
   *                        encore à explorer
   *           maxFreqNotes vaut
   *          le maximum dans notes[0...i-1]
   */
   i=0;
   while(i<N_NOTES){
     if(notes[i]>maxFreqNotes)
     maxFreqNotes = notes[i];

     i++;
   }//fin while - i

   /*
   * Affichage de la représentation graphique de l'histogramme.
   * Deux sous-problèmes ici:
   *  SP 5: Affichage de l'axe des Y
   *  SP 6: Affichage, éventuellement, d'un bout de colonne (i.e., "#######") de l'histogramme
   */
   for(i=maxFreqNotes; i>0; i--){
     //affichage de l'axe des Y
     printf("%2hu  >", i);

     for (j=0; j<7; j++){
       //affichage des colonnes de l'histogramme
       if (notes[j]>=i)
          printf(" #######");
       else
          printf("        ");
     }//fin for - j
     printf("\n");
   }//fin for - i

   /*
   * SP 7: affichage du domaine (i.e., l'axe des X) de l'histogramme.
   */
   printf("      ");
   for(i=0; i<=6; i++)
   printf("+-------");
   printf("+\n");
   printf("      ");
   for(i=0; i<=6; i++){
     switch(i){
       case 0:
          printf("I 0 - 9 ");
          break;
       case 6:
          printf("I   60  I\n");
          break;
       default:
          printf("I %d0-%d9 ", i, i);
          break;
     }//fin switch
   }//fin for - i
 }//fin programme
