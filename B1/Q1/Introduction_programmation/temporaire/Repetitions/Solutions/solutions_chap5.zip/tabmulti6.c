/*
 * Chapitre 5: Structures de Données
 * Tableaux Multi. -- Exercice 6 (Recherche de point-cols)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */
#include <stdio.h>

/*
 * Définition du Problème
 *  - Input: un matrice d'entiers de dimension NMAX*NMAX
 *  - Output: point-cols de la matrice affichés à l'écran
 *  - Objets Utilisés:
 *      NMAX est un entier Naturel.  Il ne doit pas être modifié dans le code.
 *        const unsigned short M = 50;
 *      A est une matrice de valeurs entières.
 *        int A[NMAX][NMAX];
 *
 * Analyse du Problème:
 *  - SP 1: remplissage de la matrice {tab} (possibilité de raffiner en 2 SPs)
 *  - SP 2: recherche du maximum sur une ligne
 *  - SP 3: marquer tous les maxima sur la ligne
 *  - SP 4: recherche du minimum sur une colonne
 *  - SP 5: marquer tous les minimas sur une colonne
 *  - SP 6: affichage des résultats (possibilité de raffiner en 2 SPs)
 *
 * Enchaînement des SPs:
 *  SP1 -> (SP2 -> SP3) -> (SP4 -> SP5) -> SP6
 */

 int main(){
   //dimension max des matrices
   const unsigned short NMAX = 50;

   //la matrice
   int A[NMAX][NMAX];

   // matrice indiquant les maxima des lignes
   int max[NMAX][NMAX];
   //matrice indiquant les minima des colonnes
   int min[NMAX][NMAX];

   //dimension des matrices.  Attention, 0<n,m<=nmAX
   unsigned short n, m;
   unsigned short i, j;

   //pour la détection des extréma
   int extrema;

   //compteur des points-cols
   unsigned int compteur;

   /*
   * Sous-problème 1: remplir la matrice tab
   */
   printf("nombre de lignes   (max. %d) : ", NMAX);
   scanf("%hu", &n );
   printf("nombre de colonnes (max. %d) : ", NMAX);
   scanf("%hu", &m );
   for (i=0; i<n; i++){
     for (j=0; j<m; j++){
       printf("Elément[%hu][%hu] : ",i,j);
       scanf("%d", &A[i][j]);
     }//fin for - j
   }//fin for -i

   /*
   * Construction de la matrice d'extrema max qui indique les positions de tous les
   * maxima sur une ligne.
   * Plusieurs sous-problèmes:
   *   SP 2: recherche du maximum sur une ligne
   *   SP 3: marquer tous les maxima sur la ligne
   */
   for(i=0; i<n; i++){
     /*
     * SP 2
     * Invariant:
     *       |0         |j         m-1|m
     *       +----------+-------------+
     * A[i]: |          |             |
     *       +----------+-------------+
     *        <--------> <----------->
     *                  encore à parcourir
     *   extrema = MAX{A[i][0], A[i][1], ..., A[i][j-1]}
     *   0 <= i < n
     *
     * Fonction de terminaison: m-j
     */
     extrema=A[i][0];
     for (j=1; j<m; j++){
       //Inv: extrema = max(A[i][0] ... A[i][j-1]), 0<=i<=n-1, 1<=j<=m-1
       if (A[i][j] > extrema)
        extrema=A[i][j];
     }//fin for - j

     // SP 3
     for (j=0; j<m; j++)
        //Inv: max[i][j-1] = (A[i][j-1]==extrema), 0<=i<=n-1, 0<=j<=m-1
        max[i][j] = (A[i][j]==extrema);

     /*
     * Note: l'instruction unique du corps de la boucle: max[i][j] = (A[i][j]==extrema);
     * n'est pas forcément "jolie" mais assez pratique à écrire.
     * Elle est équivalent à ceci:
     * if (A[i][j]==extrema)
     *      max[i][j] = 1;
     * else
     *      max[i][j] = 0;
     */
   }//fin for - i

   /* Construction de la matrice d'extrema min qui indique les positions de tous les
   * minima sur une colonne.
   * Sa construction se fait identiquement à la construction de la matrice d'extréma max.
   * Donc, 2 sous-problèmes:
   *   SP 4: recherche du minimum sur une colonne
   *   SP 5: marquer tous les minimas sur une colonne
   */
   for (j=0; j<m; j++){
     // SP 4
     extrema=A[0][j];
     for(i=1; i<n; i++){
       if (A[i][j]<extrema)
        extrema=A[i][j];
     }//fin for - i

     // SP 5
     for (i=0; i<n; i++)
      min[i][j] = (A[i][j]==extrema);
   }//fin for - j

   /*
   * SP 6: affichage des résultats.
   * Solution: les composantes qui sont marquées comme extréma dans 'max' et 'min'
   * sont des points-cols.
   */
   for(compteur=0, i=0; i<n; i++){
     for(j=0; j<m; j++){
       if (max[i][j]&&min[i][j]){
         compteur++;
         printf("point-col.: (%hu,%hu): %d\n", i, j, A[i][j]);
       }
     }//fin for - j
   }//fin for - compteur

   if(compteur==0)
   printf("Le tableau ne contient pas de points-cols.\n");
}//fin programme
