/*
 * Chapitre 5: Structures de Données
 * Algo. tableaux -- Exercice 3 (nombre d'occurrences de toutes les valeurs)
 *
 * @author: Benoit Donnet (ULiège)
 * Mise à Jour: Novembre 2018
 */

#include <stdio.h>
#include <stdlib.h> //=> pour la génération aléatoire

/*
 * Défintion du Problème
 *  - Input: un tableau de N valeurs entières strictement positives
 *  - Output: nombre d'occurrences de chacune des valeurs du tableau est affiché
 *            à l'écran
 *  - Objets Utilisés:
 *      N est un entier Naturel.  Il ne doit pas être modifié dans le code
 *        const unsigned short N = 50;
 *      tab est un tableau d'entiers strictement positifs (\in N_0)
 *        unsigned int tab[N];
 *
 * Afin de ne pas calculer plusieurs fois les occurences d'une même valeur
 * dans le tableau, on va utiliser un tableau intermédiaire, {occurrence},
 * dont la taille correspond au maximum de {tab} (on considère que {tab} contient
 * des valeurs dans l'intervalle [0; 9].  Par définition, la case {i}
 * de {occurrence} maintient le nombre d'occurrences pour {tab[i]}
 *
 * Analyse du Problème:
 *  - SP 1: remplissage du tableau {tab}
 *  - SP 2: initialisation de {occurrence}
 *  - SP 3: calcul du nombre d'occurences de {tab} et mise à jour de {occurrence}
 *  - SP 4: affichage des différentes occurrences
 *
 * Enchaînement des SPs:
 *  SP1 -> SP2 -> SP3 -> SP4
 */

int main(){
  const unsigned short N = 50;
  const unsigned short VAL_MAX = 10;

  unsigned int tab[N];
  unsigned int occurrence[VAL_MAX];

  unsigned short i;

  /*
   * SP 1: remplissage du tableau.
   * Pour l'exerccie, nous allons générer aléatoirement des notes entre 0 et
   * 9.
   *
   * Inv:
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
	 *          rempli       encore à remplir
	 *        avec des valeurs
   *        \in [0, 9]
   *
   * Fonction de terminaison: N-i
   */
  i = 0;
  while(i<N){
    tab[i] = rand()%VAL_MAX;
    i++;
  }//fin while - i

  /*
   * SP 2: initialisation de {occurrence}.
   *
   * Comme à chaque indice de {occurrence} correspond une somme cumulative
   * (i.e., le # d'occurrences pour {tab[i]}), il faut initialiser à 0
   * chacune des cases de {occurrence}.
   *
   * Inv:
   * Inv:
   *              |0         |i   VAL_MAX-1|VAL_MAX
	 *              +----------+-------------+
	 * occurrence:  |  .==0    |             |
	 *              +----------+-------------+
   *
   * Fonction de terminaison: VAL_MAX-i
   */
  i = 0;
  while(i<VAL_MAX){
    occurrence[i] = 0;
    i++;
  }//fin while - i

  /*
   * SP 3: calcul du nombre d'occurrences.
   *
   * Inv:
   *       |0         |i         N-1|N
	 *       +----------+-------------+
	 * tab:  |          |             |
	 *       +----------+-------------+
	 *        <--------> <----------->
   *         parcouru      encore à parcourir
   * avec pour tout k, 0<=k<VAL_MAX, pour tout j, 0<=j<i<=N,
   *      occurrence[k] = #(tab[j]==k)
   *
   * Fonction de terminaison: N-i
   */
  i = 0;
  while(i<N){
    occurrence[tab[i]]++;
    i++;
  }//fin while - i

  /*
   * SP 4: affichage des différentes occurrences
   *
   * Inv:
   *              |0         |i   VAL_MAX-1|VAL_MAX
	 *              +----------+-------------+
	 * occurrence:  |          |             |
	 *              +----------+-------------+
	 *               <--------> <----------->
   *                affiché        encore à afficher
   *                à l'écran
   *
   * Fonction de terminaison: VAL_MAX-i
   */
  i = 0;
  while(i<VAL_MAX){
    printf("# d'occurrences de %hu: %u\n", i, occurrence[i]);
    i++;
  }//fin while - i
}//fin programme
